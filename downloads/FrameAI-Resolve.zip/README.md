# FrameAI Studio — Script per DaVinci Resolve

Pannello nativo (UIManager di Fusion, zero dipendenze) che genera video
con FrameAI e li importa direttamente nel **Media Pool**.

Funziona sia con Resolve **gratuito** che **Studio** quando lanciato
dall'interno di Resolve (menu Scripts). L'esecuzione da terminale esterno
richiede invece Resolve Studio.

---

## ⚙️ Installazione

### 1. Configura le chiavi
Apri `FrameAI_Studio.py` e compila in cima:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

### 2. Copia lo script nella cartella Scripts di Resolve

- **Windows:** `C:\ProgramData\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility\`
- **macOS:** `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/`
- **Linux:** `/opt/resolve/Fusion/Scripts/Utility/`

(in alternativa la cartella utente:
`%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility`)

### 3. Verifica le impostazioni di scripting
In Resolve: `Preferences → System → General → External scripting using` →
imposta almeno **Local**.

### 4. Lancia
`Workspace → Scripts → FrameAI_Studio` — si apre la finestra del pannello.

---

## 🎬 Come funziona

1. Login con le credenziali FrameAI
2. Prompt + modello + formato + durata + risoluzione, stima crediti live
3. Generazione in un thread separato (la finestra resta reattiva)
4. Video scaricato in `~/FrameAI-Videos/`
5. Import automatico nel **Media Pool** del progetto corrente
   (`MediaPool.ImportMedia`) — poi trascini la clip in timeline

## 📝 Note

- La UI usa UIManager (lo stesso sistema dei tool Fusion): nessun pip,
  nessuna dipendenza, gira con il Python integrato/configurato di Resolve
- Se l'aggiornamento live dello stato desse problemi su qualche versione
  di Resolve, il fallback più robusto è spostare gli update UI su un
  timer — segnalamelo e lo sistemiamo
- Possibile evoluzione: import direttamente nella timeline alla posizione
  del playhead (`MediaPool.AppendToTimeline`)
