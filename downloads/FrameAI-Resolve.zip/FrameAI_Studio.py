# ============================================================
# FrameAI Studio — Script per DaVinci Resolve
# Si lancia da: Workspace -> Scripts -> FrameAI_Studio
# UI costruita con UIManager (nativa Resolve/Fusion, zero dipendenze)
# v2: Video + Immagine + Tools
# ============================================================

import json
import math
import os
import threading
import urllib.request
import urllib.error
import uuid
import mimetypes
from datetime import datetime

# ── CONFIGURAZIONE ──────────────────────────────────────────
SUPABASE_URL = "https://vyngrcrudvxoxbehwrqv.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0"

POLL_INTERVAL_S = 6
MAX_POLLS = 200
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "FrameAI-Videos")

# ── Modelli video (allineati al sito) ───────────────────────
MODELS = [
    ("LTX-2 (Free)", "ltx-2"),
    ("Seedance Fast (Starter)", "seedance-fast"),
    ("Wan 2.6 (Starter)", "wan-2.6"),
    ("Kling 3.0 (Creator)", "kling-3.0"),
    ("Seedance 2.0 (Creator)", "seedance-2.0"),
    ("Sora 2 (Business)", "sora-2"),
    ("Veo 3.1 (Agency)", "veo-3.1"),
]
RATIOS = ["16:9", "9:16", "1:1", "21:9", "4:3"]
DURATIONS = [5, 8, 10, 15]
RESOLUTIONS = ["720p", "1080p"]

# ── Modelli immagine ────────────────────────────────────────
IMAGE_MODELS = [
    ("Flux Schnell (Free)", "flux-schnell"),
    ("Flux Dev (Starter)", "flux-dev"),
    ("Flux 2 (Starter)", "flux2"),
    ("Nano Banana 2 (Creator)", "nano-banana-2"),
    ("Nano Banana Pro (Business)", "nano-banana-pro"),
    ("Seedream (Starter)", "seedream"),
]
IMAGE_RATIOS = ["1:1", "16:9", "9:16", "4:3"]
_IMG_COST = {
    "flux-schnell": 1, "flux-dev": 1, "flux2": 2,
    "nano-banana-2": 2, "nano-banana-pro": 3, "seedream": 1,
}

# ── Tools (id, label, categoria, crediti, serve_prompt) ─────
TOOLS = [
    ("upscale-image",       "Upscale Immagine",       "image", 1, False),
    ("enhance-photo",       "Migliora Foto AI",        "image", 2, False),
    ("remove-bg",           "Rimuovi Sfondo",          "image", 1, False),
    ("remove-object",       "Rimuovi Oggetto",         "image", 3, True),
    ("upscale-video",       "Upscale Video",           "video", 4, False),
    ("remove-bg-video",     "Rimuovi Sfondo Video",    "video", 2, False),
    ("remove-bg-video-pro", "Rimuovi Sfondo Video Pro","video", 5, False),
    ("remove-object-video", "Rimuovi Oggetto Video",   "video", 8, True),
]

_MAX_COST_PER_CREDIT = 0.063
_COST_PER_SEC = {
    "ltx-2": 0.004, "wan-2.6": 0.100, "seedance-2.0": 0.303,
    "seedance-fast": 0.242, "kling-3.0": 0.140, "sora-2": 0.150,
    "veo-3.1": 0.200,
}
_RES_MULT = {"720p": 1.0, "1080p": 1.5}


def credit_cost(model, duration, resolution="720p"):
    per_sec = _COST_PER_SEC.get(model, 0.10)
    usd = per_sec * duration * _RES_MULT.get(resolution, 1.0)
    return max(1, math.ceil(usd / _MAX_COST_PER_CREDIT))


def credit_cost_image(model):
    return _IMG_COST.get(model, 1)


def _request(url, payload=None, headers=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET")
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=120) as res:
            return json.loads(res.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {}
        raise RuntimeError(body.get("error") or body.get("error_description")
                           or body.get("msg") or str(e))


class Client(object):
    def __init__(self):
        self.session = None

    def login(self, email, password):
        d = _request(SUPABASE_URL + "/auth/v1/token?grant_type=password",
                     {"email": email, "password": password},
                     {"apikey": SUPABASE_ANON_KEY})
        self.session = {"token": d["access_token"],
                        "user_id": d.get("user", {}).get("id")}

    def _h(self, token):
        return {"Authorization": "Bearer " + token, "apikey": SUPABASE_ANON_KEY}

    def profile(self):
        rows = _request(SUPABASE_URL + "/rest/v1/profiles?id=eq.%s&select=credits,plan"
                        % self.session["user_id"], headers=self._h(self.session["token"]))
        if not rows:
            raise RuntimeError("Impossibile leggere il profilo")
        return rows[0]

    def generate(self, payload):
        d = _request(SUPABASE_URL + "/functions/v1/generate-video",
                     payload, self._h(self.session["token"]))
        if not d.get("id") or not d.get("modelId"):
            raise RuntimeError(d.get("error", "Risposta non valida"))
        return d

    def poll(self, job_id, model_id):
        return _request(SUPABASE_URL + "/functions/v1/poll-video",
                        {"requestId": job_id, "falEndpoint": model_id},
                        self._h(SUPABASE_ANON_KEY))

    def generate_image(self, payload):
        d = _request(SUPABASE_URL + "/functions/v1/generate-image",
                     payload, self._h(self.session["token"]))
        if d.get("error"):
            raise RuntimeError(d["error"])
        out = d.get("output") or []
        url = out[0] if out else (d.get("imageUrl") or d.get("url"))
        if not url:
            raise RuntimeError("Nessuna immagine restituita")
        return url

    def upload_temp(self, file_path):
        boundary = "----FrameAIResolve" + uuid.uuid4().hex
        with open(file_path, "rb") as fh:
            content = fh.read()
        fname = os.path.basename(file_path)
        ctype = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        body = b""
        body += ("--%s\r\n" % boundary).encode()
        body += ("Content-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n" % fname).encode()
        body += ("Content-Type: %s\r\n\r\n" % ctype).encode()
        body += content + b"\r\n"
        body += ("--%s--\r\n" % boundary).encode()
        req = urllib.request.Request(SUPABASE_URL + "/functions/v1/upload-temp",
                                     data=body, method="POST")
        req.add_header("Content-Type", "multipart/form-data; boundary=%s" % boundary)
        req.add_header("Authorization", "Bearer " + self.session["token"])
        req.add_header("apikey", SUPABASE_ANON_KEY)
        with urllib.request.urlopen(req, timeout=180) as res:
            d = json.loads(res.read().decode("utf-8"))
        if not d.get("url"):
            raise RuntimeError("Upload del file fallito")
        return d["url"]

    def tools_process(self, payload):
        return _request(SUPABASE_URL + "/functions/v1/tools-process",
                        payload, self._h(self.session["token"]))

    def tool_job_status(self, job_id):
        rows = _request(SUPABASE_URL + "/rest/v1/tool_jobs?id=eq.%s&select=status,output_url,error_msg,fal_progress"
                        % job_id, headers=self._h(self.session["token"]))
        return rows[0] if rows else None

    def consume(self, amount):
        try:
            _request(SUPABASE_URL + "/functions/v1/consume-credits",
                     {"userId": self.session["user_id"], "amount": amount},
                     self._h(self.session["token"]))
        except Exception:
            pass

    def save(self, file_url, meta):
        try:
            p = {"userId": self.session["user_id"], "fileUrl": file_url}
            p.update(meta)
            _request(SUPABASE_URL + "/functions/v1/save-generation",
                     p, self._h(self.session["token"]))
        except Exception:
            pass


# ── Resolve / UI ────────────────────────────────────────────
try:
    resolve  # noqa
except NameError:
    import DaVinciResolveScript as dvr
    resolve = dvr.scriptapp("Resolve")
try:
    bmd  # noqa
except NameError:
    import DaVinciResolveScript as dvr
    bmd = dvr

fu = resolve.Fusion()
ui = fu.UIManager
disp = bmd.UIDispatcher(ui)

client = Client()
busy = {"flag": False}
tool_file = {"path": None}

win = disp.AddWindow(
    {"ID": "FrameAIWin", "WindowTitle": "FrameAI Studio",
     "Geometry": [200, 150, 430, 640]},
    [
        ui.VGroup({"Spacing": 6}, [
            ui.Label({"ID": "Header", "Text": "<b>FrameAI</b> Studio · Resolve",
                      "Alignment": {"AlignHCenter": True}}),
            ui.Label({"ID": "Credits", "Text": "", "Alignment": {"AlignHCenter": True}}),

            # — login —
            ui.VGroup({"ID": "LoginGroup", "Spacing": 4}, [
                ui.LineEdit({"ID": "Email", "PlaceholderText": "Email FrameAI"}),
                ui.LineEdit({"ID": "Password", "PlaceholderText": "Password",
                             "EchoMode": "Password"}),
                ui.Button({"ID": "LoginBtn", "Text": "Accedi"}),
            ]),

            # — selettore modalità —
            ui.HGroup({"ID": "ModeBar", "Spacing": 2, "Hidden": True, "Weight": 0}, [
                ui.Button({"ID": "ModeVideo", "Text": "🎬 Video", "Checkable": True, "Checked": True}),
                ui.Button({"ID": "ModeImage", "Text": "🖼 Immagine", "Checkable": True}),
                ui.Button({"ID": "ModeTools", "Text": "🔧 Tools", "Checkable": True}),
            ]),

            # — VIDEO —
            ui.VGroup({"ID": "VideoGroup", "Spacing": 4, "Hidden": True}, [
                ui.TextEdit({"ID": "Prompt", "PlaceholderText":
                             "Descrivi la scena... (in italiano)"}),
                ui.HGroup({}, [
                    ui.ComboBox({"ID": "Model"}),
                    ui.ComboBox({"ID": "Ratio", "Weight": 0.4}),
                ]),
                ui.HGroup({}, [
                    ui.ComboBox({"ID": "Duration"}),
                    ui.ComboBox({"ID": "Resolution"}),
                    ui.Label({"ID": "Cost", "Text": ""}),
                ]),
                ui.CheckBox({"ID": "AutoImport",
                             "Text": "Importa nel Media Pool", "Checked": True}),
                ui.Button({"ID": "GenerateBtn", "Text": "🎬 Genera video"}),
            ]),

            # — IMMAGINE —
            ui.VGroup({"ID": "ImageGroup", "Spacing": 4, "Hidden": True}, [
                ui.TextEdit({"ID": "ImgPrompt", "PlaceholderText":
                             "Descrivi l'immagine... (in italiano)"}),
                ui.HGroup({}, [
                    ui.ComboBox({"ID": "ImgModel"}),
                    ui.ComboBox({"ID": "ImgRatio", "Weight": 0.4}),
                ]),
                ui.HGroup({}, [
                    ui.Label({"ID": "ImgCost", "Text": ""}),
                ]),
                ui.CheckBox({"ID": "ImgAutoImport",
                             "Text": "Importa nel Media Pool", "Checked": True}),
                ui.Button({"ID": "ImgGenerateBtn", "Text": "🖼 Genera immagine"}),
            ]),

            # — TOOLS —
            ui.VGroup({"ID": "ToolsGroup", "Spacing": 4, "Hidden": True}, [
                ui.ComboBox({"ID": "ToolSelect"}),
                ui.Label({"ID": "ToolHint", "Text": "", "WordWrap": True}),
                ui.LineEdit({"ID": "ToolPrompt",
                             "PlaceholderText": "Cosa rimuovere (in inglese): the car...",
                             "Hidden": True}),
                ui.Button({"ID": "ToolFileBtn", "Text": "📁 Scegli file..."}),
                ui.Label({"ID": "ToolFileLbl", "Text": "", "WordWrap": True}),
                ui.CheckBox({"ID": "ToolAutoImport",
                             "Text": "Importa nel Media Pool", "Checked": True}),
                ui.Button({"ID": "ToolRunBtn", "Text": "🔧 Elabora"}),
            ]),

            ui.Label({"ID": "Status", "Text": "", "WordWrap": True}),
        ]),
    ])

itm = win.GetItems()
itm["Model"].AddItems([m[0] for m in MODELS])
itm["Model"].CurrentIndex = 2  # wan-2.6
itm["Ratio"].AddItems(RATIOS)
itm["Duration"].AddItems(["%ds" % d for d in DURATIONS])
itm["Resolution"].AddItems(RESOLUTIONS)
itm["ImgModel"].AddItems([m[0] for m in IMAGE_MODELS])
itm["ImgModel"].CurrentIndex = 1  # flux-dev
itm["ImgRatio"].AddItems(IMAGE_RATIOS)
itm["ToolSelect"].AddItems(["%s  (%dcr)" % (t[1], t[3]) for t in TOOLS])


def set_status(text):
    itm["Status"].Text = text


def update_cost(ev=None):
    cost = credit_cost(MODELS[itm["Model"].CurrentIndex][1],
                       DURATIONS[itm["Duration"].CurrentIndex],
                       RESOLUTIONS[itm["Resolution"].CurrentIndex])
    itm["Cost"].Text = "⚡ %dcr" % cost


def update_img_cost(ev=None):
    cost = credit_cost_image(IMAGE_MODELS[itm["ImgModel"].CurrentIndex][1])
    itm["ImgCost"].Text = "⚡ %dcr" % cost


def update_tool_hint(ev=None):
    t = TOOLS[itm["ToolSelect"].CurrentIndex]
    cat, needs_prompt = t[2], t[4]
    itm["ToolHint"].Text = ("Input: %s · il risultato viene importato nel Media Pool."
                            % ("video" if cat == "video" else "immagine"))
    itm["ToolPrompt"].Hidden = not needs_prompt
    tool_file["path"] = None
    itm["ToolFileLbl"].Text = ""


def set_mode(mode):
    itm["VideoGroup"].Hidden = (mode != "video")
    itm["ImageGroup"].Hidden = (mode != "image")
    itm["ToolsGroup"].Hidden = (mode != "tools")
    itm["ModeVideo"].Checked = (mode == "video")
    itm["ModeImage"].Checked = (mode == "image")
    itm["ModeTools"].Checked = (mode == "tools")
    set_status("")


def do_login(ev):
    try:
        client.login(itm["Email"].Text.strip(), itm["Password"].Text)
        p = client.profile()
        itm["Credits"].Text = "⚡ %scr · %s" % (p["credits"], p["plan"])
        itm["LoginGroup"].Hidden = True
        itm["ModeBar"].Hidden = False
        set_mode("video")
        update_cost()
        update_img_cost()
        update_tool_hint()
    except Exception as e:
        set_status("Errore: %s" % e)


def refresh_credits():
    try:
        p = client.profile()
        itm["Credits"].Text = "⚡ %scr · %s" % (p["credits"], p["plan"])
    except Exception:
        pass


def import_to_media_pool(file_path):
    pm = resolve.GetProjectManager()
    proj = pm.GetCurrentProject()
    if not proj:
        raise RuntimeError("Nessun progetto aperto in Resolve")
    mp = proj.GetMediaPool()
    items = mp.ImportMedia([file_path])
    if not items:
        raise RuntimeError("Import fallito — trascina il file manualmente: " + file_path)


def _ensure_dir():
    if not os.path.isdir(DOWNLOAD_DIR):
        os.makedirs(DOWNLOAD_DIR)


def _set_busy(flag):
    busy["flag"] = flag
    itm["GenerateBtn"].Enabled = not flag
    itm["ImgGenerateBtn"].Enabled = not flag
    itm["ToolRunBtn"].Enabled = not flag


# ── Worker VIDEO ────────────────────────────────────────────
def worker_video(payload, credits_used):
    try:
        set_status("Avvio generazione...")
        job = client.generate(payload)
        url = None
        for i in range(MAX_POLLS):
            result = client.poll(job["id"], job["modelId"])
            url = result.get("outputUrl") or (result.get("output") or [None])[0]
            prog = result.get("progress") or 0
            set_status("Rendering... %d%%" % int(prog) if prog > 0
                       else "Rendering in corso... (%s)" % payload["model"])
            done = result.get("done") or result.get("status") in ("success", "COMPLETED")
            if done and url:
                break
            if result.get("status") == "error":
                raise RuntimeError(result.get("error", "Rendering fallito"))
            threading.Event().wait(POLL_INTERVAL_S)
        if not url:
            raise RuntimeError("Timeout — riprova con durata minore.")
        client.consume(credits_used)
        client.save(url, {"type": "video", "prompt": payload["prompt"],
                          "model": payload["model"],
                          "aspectRatio": payload["aspectRatio"],
                          "creditsUsed": credits_used})
        set_status("Download del video...")
        _ensure_dir()
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        fp = os.path.join(DOWNLOAD_DIR, "frameai_%s.mp4" % stamp)
        urllib.request.urlretrieve(url, fp)
        if itm["AutoImport"].Checked:
            set_status("Import nel Media Pool...")
            import_to_media_pool(fp)
        refresh_credits()
        set_status("✅ Video pronto: " + fp)
    except Exception as e:
        set_status("Errore: %s" % e)
    finally:
        _set_busy(False)


# ── Worker IMMAGINE ─────────────────────────────────────────
def worker_image(payload, credits_used):
    try:
        set_status("Generazione immagine...")
        url = client.generate_image(payload)
        client.consume(credits_used)
        client.save(url, {"type": "image", "prompt": payload.get("prompt", ""),
                          "model": payload.get("model", ""),
                          "creditsUsed": credits_used})
        set_status("Download...")
        _ensure_dir()
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        fp = os.path.join(DOWNLOAD_DIR, "frameai_img_%s.jpg" % stamp)
        urllib.request.urlretrieve(url, fp)
        if itm["ImgAutoImport"].Checked:
            import_to_media_pool(fp)
        refresh_credits()
        set_status("✅ Immagine pronta: " + fp)
    except Exception as e:
        set_status("Errore: %s" % e)
    finally:
        _set_busy(False)


# ── Worker TOOLS ────────────────────────────────────────────
def worker_tool(tool_id, input_path, is_video, credits_used, prompt):
    try:
        set_status("Upload del file...")
        file_url = client.upload_temp(input_path)
        set_status("Elaborazione AI...")
        payload = {"tool": tool_id, "fileUrl": file_url,
                   "userId": client.session["user_id"], "credits": credits_used}
        if prompt:
            payload["bgPrompt"] = prompt
        resp = client.tools_process(payload)
        if resp.get("error"):
            raise RuntimeError(resp["error"])
        out_url = resp.get("outputUrl")
        if not out_url and resp.get("jobId"):
            job_id = resp["jobId"]
            for i in range(MAX_POLLS):
                threading.Event().wait(POLL_INTERVAL_S)
                status = client.tool_job_status(job_id)
                if not status:
                    continue
                prog = status.get("fal_progress") or 0
                set_status("Elaborazione... %d%%" % int(prog) if prog > 0
                           else "Elaborazione in corso...")
                if status.get("status") == "done" and status.get("output_url"):
                    out_url = status["output_url"]
                    break
                if status.get("status") == "failed":
                    raise RuntimeError(status.get("error_msg") or "Elaborazione fallita")
        if not out_url:
            raise RuntimeError("Timeout — nessun output dal tool.")
        client.consume(credits_used)
        set_status("Download del risultato...")
        _ensure_dir()
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        ext = "mp4" if is_video else ("png" if tool_id == "remove-bg" else "jpg")
        fp = os.path.join(DOWNLOAD_DIR, "frameai_%s_%s.%s" % (tool_id, stamp, ext))
        urllib.request.urlretrieve(out_url, fp)
        if itm["ToolAutoImport"].Checked:
            import_to_media_pool(fp)
        refresh_credits()
        set_status("✅ Risultato pronto: " + fp)
    except Exception as e:
        set_status("Errore: %s" % e)
    finally:
        _set_busy(False)


# ── Azioni ──────────────────────────────────────────────────
def do_generate(ev):
    if busy["flag"]:
        return
    prompt = itm["Prompt"].PlainText.strip()
    if not prompt:
        set_status("Scrivi un prompt prima di generare.")
        return
    model = MODELS[itm["Model"].CurrentIndex][1]
    duration = DURATIONS[itm["Duration"].CurrentIndex]
    resolution = RESOLUTIONS[itm["Resolution"].CurrentIndex]
    credits_used = credit_cost(model, duration, resolution)
    try:
        p = client.profile()
        if p["credits"] < credits_used:
            set_status("Crediti insufficienti — hai %scr, servono %dcr." % (p["credits"], credits_used))
            return
    except Exception as e:
        set_status("Errore: %s" % e)
        return
    payload = {"prompt": prompt, "model": model,
               "aspectRatio": RATIOS[itm["Ratio"].CurrentIndex],
               "duration": duration, "resolution": resolution}
    _set_busy(True)
    t = threading.Thread(target=worker_video, args=(payload, credits_used))
    t.daemon = True
    t.start()


def do_generate_image(ev):
    if busy["flag"]:
        return
    prompt = itm["ImgPrompt"].PlainText.strip()
    if not prompt:
        set_status("Scrivi un prompt prima di generare.")
        return
    model = IMAGE_MODELS[itm["ImgModel"].CurrentIndex][1]
    credits_used = credit_cost_image(model)
    try:
        p = client.profile()
        if p["credits"] < credits_used:
            set_status("Crediti insufficienti — hai %scr, servono %dcr." % (p["credits"], credits_used))
            return
    except Exception as e:
        set_status("Errore: %s" % e)
        return
    payload = {"prompt": prompt, "model": model,
               "ratio": IMAGE_RATIOS[itm["ImgRatio"].CurrentIndex],
               "resolution": "1024"}
    _set_busy(True)
    t = threading.Thread(target=worker_image, args=(payload, credits_used))
    t.daemon = True
    t.start()


def pick_tool_file(ev):
    t = TOOLS[itm["ToolSelect"].CurrentIndex]
    cat = t[2]
    if cat == "video":
        filt = "*.mp4;*.mov;*.webm;*.avi"
    else:
        filt = "*.png;*.jpg;*.jpeg;*.webp;*.tif;*.tiff"
    # FReqS_Filter limita i tipi di file mostrati nella finestra di selezione.
    # FReqB_SeqGather:False evita che Fusion interpreti il file come sequenza.
    try:
        selection = fu.RequestFile("", "", {
            "FReqB_SeqGather": False,
            "FReqS_Filter": filt,
        })
    except Exception as e:
        set_status("Errore nella finestra di selezione file: %s" % e)
        return
    if selection:
        tool_file["path"] = selection
        itm["ToolFileLbl"].Text = "✓ " + os.path.basename(selection)


def do_run_tool(ev):
    if busy["flag"]:
        return
    if not tool_file["path"]:
        set_status("Scegli un file da elaborare.")
        return
    t = TOOLS[itm["ToolSelect"].CurrentIndex]
    tool_id, cat, credits_used, needs_prompt = t[0], t[2], t[3], t[4]
    is_video = (cat == "video")
    prompt = itm["ToolPrompt"].Text.strip() if needs_prompt else None
    if needs_prompt and not prompt:
        set_status("Scrivi cosa rimuovere.")
        return
    try:
        p = client.profile()
        if p["credits"] < credits_used:
            set_status("Crediti insufficienti — hai %scr, servono %dcr." % (p["credits"], credits_used))
            return
    except Exception as e:
        set_status("Errore: %s" % e)
        return
    _set_busy(True)
    t2 = threading.Thread(target=worker_tool,
                          args=(tool_id, tool_file["path"], is_video, credits_used, prompt))
    t2.daemon = True
    t2.start()


def on_close(ev):
    disp.ExitLoop()


win.On.FrameAIWin.Close = on_close
win.On.LoginBtn.Clicked = do_login
win.On.ModeVideo.Clicked = lambda ev: set_mode("video")
win.On.ModeImage.Clicked = lambda ev: set_mode("image")
win.On.ModeTools.Clicked = lambda ev: set_mode("tools")
win.On.GenerateBtn.Clicked = do_generate
win.On.ImgGenerateBtn.Clicked = do_generate_image
win.On.ToolFileBtn.Clicked = pick_tool_file
win.On.ToolRunBtn.Clicked = do_run_tool
win.On.Model.CurrentIndexChanged = update_cost
win.On.Duration.CurrentIndexChanged = update_cost
win.On.Resolution.CurrentIndexChanged = update_cost
win.On.ImgModel.CurrentIndexChanged = update_img_cost
win.On.ToolSelect.CurrentIndexChanged = update_tool_hint

if SUPABASE_URL.find("INSERISCI") != -1:
    set_status("⚠️ Configurazione mancante: compila SUPABASE_URL e SUPABASE_ANON_KEY.")

update_cost()
win.Show()
disp.RunLoop()
win.Hide()
