#!/usr/bin/env node
// ============================================================
// FrameAI MCP Server v1.0
// Espone la generazione video/immagini di FrameAI Studio come
// tool MCP per Claude Desktop / Claude Code.
//
// Config (variabili d'ambiente nel claude_desktop_config.json):
//   FRAMEAI_SUPABASE_URL  — URL del progetto Supabase FrameAI
//   FRAMEAI_ANON_KEY      — anon key pubblica FrameAI
//   FRAMEAI_EMAIL         — email dell'account FrameAI dell'utente
//   FRAMEAI_PASSWORD      — password dell'account
// ============================================================
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const SUPABASE_URL = process.env.FRAMEAI_SUPABASE_URL ?? ''
const ANON_KEY     = process.env.FRAMEAI_ANON_KEY     ?? ''
const EMAIL        = process.env.FRAMEAI_EMAIL        ?? ''
const PASSWORD     = process.env.FRAMEAI_PASSWORD     ?? ''

if (!SUPABASE_URL || !ANON_KEY || !EMAIL || !PASSWORD) {
  console.error('[frameai-mcp] Config mancante: servono FRAMEAI_SUPABASE_URL, FRAMEAI_ANON_KEY, FRAMEAI_EMAIL, FRAMEAI_PASSWORD')
  process.exit(1)
}

// ── Sistema crediti (replica di src/lib/credits.ts) ─────────
const MAX_API_COST_PER_CREDIT_USD = 0.063
const RES_MULT = { '720p': 1.0, '1080p': 1.5, '4k': 2.5 }

const VIDEO_MODELS = {
  'ltx-2':         { costSec: 0.004, audio: true,  minPlan: 'free',     durations: [5, 8, 10],  label: 'LTX-2 (Lightricks)' },
  'wan-2.6':       { costSec: 0.100, audio: false, minPlan: 'starter',  durations: [5, 10],     label: 'Wan 2.6 (Alibaba)' },
  'seedance-mini': { costSec: 0.072, audio: true,  minPlan: 'starter',  durations: [5, 8, 10],  label: 'Seedance 2.0 Mini (ByteDance)' },
  'seedance-fast': { costSec: 0.242, audio: true,  minPlan: 'starter',  durations: [5, 8, 10],  label: 'Seedance Fast (ByteDance)' },
  'seedance-1.5':  { costSec: 0.052, audio: true,  minPlan: 'starter',  durations: [5, 8, 10],  label: 'Seedance 1.5 (ByteDance)' },
  'seedance-2.0':  { costSec: 0.303, audio: true,  minPlan: 'creator',  durations: [5, 8, 10],  label: 'Seedance 2.0 (ByteDance)' },
  'kling-3.0':     { costSec: 0.140, audio: true,  minPlan: 'creator',  durations: [5, 8, 10],  label: 'Kling 3.0 (Kuaishou)' },
  'kling-turbo':   { costSec: 0.112, audio: true,  minPlan: 'creator',  durations: [5, 8, 10],  label: 'Kling 3.0 Turbo (Kuaishou)' },
  'kling-o3':      { costSec: 0.112, audio: true,  minPlan: 'business', durations: [5, 10, 15], label: 'Kling O3 keyframe control (Kuaishou)' },
  'veo-3.1':       { costSec: 0.200, audio: true,  minPlan: 'business', durations: [4, 6, 8],   label: 'Veo 3.1 Fast (Google)' },
  'veo-3.1-lite':  { costSec: 0.080, audio: true,  minPlan: 'business', durations: [4, 6, 8],   label: 'Veo 3.1 Lite (Google)' },
}
const FOURK_MODELS = new Set(['seedance-2.0', 'seedance-mini', 'seedance-fast'])

const IMAGE_MODELS = {
  'flux-schnell':    { cost1024: 0.003, minPlan: 'free',     label: 'FLUX Schnell — veloce ed economico' },
  'flux-dev':        { cost1024: 0.025, minPlan: 'starter',  label: 'FLUX Dev — fotorealismo' },
  'flux2':           { cost1024: 0.040, minPlan: 'starter',  label: 'FLUX 2.0 Pro' },
  'flux2-pro':       { cost1024: 0.030, minPlan: 'starter',  label: 'FLUX 2 Pro — studio grade' },
  'gpt-image-2':     { cost1024: 0.053, minPlan: 'starter',  label: 'GPT Image 2 (OpenAI) — testo/loghi perfetti nelle immagini' },
  'nano-banana-2':   { cost1024: 0.080, minPlan: 'creator',  label: 'Nano Banana 2 (Google) — personaggi coerenti' },
  'nano-banana-pro': { cost1024: 0.150, minPlan: 'business', label: 'Nano Banana Pro (Google)' },
  'seedream':        { cost1024: 0.035, minPlan: 'business', label: 'Seedream 5.0 (ByteDance) — anime/illustrazione' },
}

function videoCredits(model, duration, resolution) {
  const m = VIDEO_MODELS[model]
  const cost = (m?.costSec ?? 0.10) * duration * (RES_MULT[resolution] ?? 1.0)
  return Math.max(1, Math.ceil(cost / MAX_API_COST_PER_CREDIT_USD))
}
function imageCredits(model) {
  const cost = IMAGE_MODELS[model]?.cost1024 ?? 0.025
  return Math.max(1, Math.ceil(cost / MAX_API_COST_PER_CREDIT_USD))
}

// ── Autenticazione Supabase (login password + cache token) ──
let session = null // { token, userId, exp }

async function login() {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'apikey': ANON_KEY },
    body: JSON.stringify({ email: EMAIL, password: PASSWORD }),
  })
  const data = await res.json()
  if (!res.ok || !data.access_token) {
    throw new Error(`Login FrameAI fallito: ${data.error_description ?? data.msg ?? res.status}. Controlla email/password nella config MCP.`)
  }
  session = {
    token:  data.access_token,
    userId: data.user.id,
    exp:    Date.now() + Math.max(60, (data.expires_in ?? 3600) - 120) * 1000,
  }
  return session
}

async function getSession() {
  if (!session || Date.now() > session.exp) await login()
  return session
}

// ── Helpers HTTP ─────────────────────────────────────────────
async function edgeFn(name, body, bearerToken) {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/${name}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${bearerToken}`,
      'apikey': ANON_KEY,
    },
    body: JSON.stringify(body),
  })
  const text = await res.text()
  let data
  try { data = JSON.parse(text) } catch { data = { error: text } }
  if (!res.ok) throw new Error(data?.error ?? `${name} fallita (HTTP ${res.status})`)
  return data
}

async function getProfile() {
  const s = await getSession()
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/profiles?id=eq.${s.userId}&select=credits,plan`,
    { headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${s.token}` } }
  )
  const rows = await res.json()
  if (!Array.isArray(rows) || !rows[0]) throw new Error('Profilo FrameAI non trovato')
  return rows[0] // { credits, plan }
}

async function consumeCredits(amount) {
  const s = await getSession()
  try { await edgeFn('consume-credits', { userId: s.userId, amount }, s.token) } catch { /* non bloccante */ }
}

async function saveGeneration(fileUrl, meta) {
  const s = await getSession()
  try { await edgeFn('save-generation', { userId: s.userId, fileUrl, ...meta }, s.token) } catch { /* non bloccante */ }
}

// ── Generazione video riusabile (submit + polling) ──────────
async function generateOneVideo({ prompt, model, aspectRatio, duration, resolution, imageUrl, notify, progFrom = 10, progTo = 95, label = 'Rendering' }) {
  const s = await getSession()
  const job = await edgeFn('generate-video', { prompt, model, aspectRatio, imageUrl, duration, resolution }, s.token)
  if (job.error) throw new Error(job.error)
  if (!job.id || !job.modelId) throw new Error('Job non avviato correttamente. Riprova.')

  const POLL_MS = 6000
  const MAX_POLLS = 200
  for (let i = 1; i <= MAX_POLLS; i++) {
    await new Promise(r => setTimeout(r, POLL_MS))
    const result = await edgeFn('poll-video', { requestId: job.id, falEndpoint: job.modelId }, ANON_KEY)
    const url = result.outputUrl ?? result.output?.[0] ?? null

    const frac = Math.min(0.95, i / 100)
    await notify?.(Math.round(progFrom + (progTo - progFrom) * frac), `${label}... (${Math.round(i * POLL_MS / 1000)}s)`)

    if ((result.done || result.status === 'success' || result.status === 'COMPLETED') && url) return url
    if (result.status === 'error') throw new Error(result.error ?? 'Rendering fallito su fal.ai')
  }
  throw new Error('Timeout: la generazione ha impiegato troppo. Riprova con durata minore o un modello più veloce.')
}

// ── Job manager: le generazioni lunghe girano in background ─
// I client MCP hanno timeout di ~60s sulle richieste: i tool video/film
// avviano un job e rispondono subito; lo stato si controlla con check_job.
const JOBS = new Map()

function newJob(kind, label) {
  const id = `${kind}-${Math.random().toString(36).slice(2, 8)}`
  const job = { id, kind, label, status: 'running', progress: 0, message: 'Avvio...', result: null, error: null, startedAt: Date.now() }
  JOBS.set(id, job)
  return job
}

function jobNotifier(job) {
  return async (progress, message) => { job.progress = progress; job.message = message }
}

// ── Server MCP ───────────────────────────────────────────────
const server = new McpServer({ name: 'frameai', version: '1.1.0' })

// TOOL: crediti e piano
server.tool(
  'frameai_get_credits',
  'Mostra i crediti FrameAI rimanenti e il piano attivo dell\'utente.',
  {},
  async () => {
    const p = await getProfile()
    return { content: [{ type: 'text', text: `Crediti disponibili: ${p.credits}\nPiano attivo: ${p.plan}` }] }
  }
)

// TOOL: elenco modelli
server.tool(
  'frameai_list_models',
  'Elenca i modelli video e immagine disponibili su FrameAI con costi in crediti e piano minimo richiesto.',
  {},
  async () => {
    const vid = Object.entries(VIDEO_MODELS).map(([id, m]) =>
      `- ${id} — ${m.label} · ${videoCredits(id, 5, '720p')}cr/5s 720p · ${m.audio ? 'audio ✓' : 'no audio'} · piano ${m.minPlan}+ · durate ${m.durations.join('/')}s${FOURK_MODELS.has(id) ? ' · supporta 4K' : ''}`
    ).join('\n')
    const img = Object.entries(IMAGE_MODELS).map(([id, m]) =>
      `- ${id} — ${m.label} · ${imageCredits(id)}cr · piano ${m.minPlan}+`
    ).join('\n')
    return { content: [{ type: 'text', text: `MODELLI VIDEO:\n${vid}\n\nMODELLI IMMAGINE:\n${img}` }] }
  }
)

// TOOL: genera immagine
server.tool(
  'frameai_generate_image',
  'Genera un\'immagine AI con FrameAI. Usa i crediti dell\'account. Restituisce l\'URL dell\'immagine generata.',
  {
    prompt:     z.string().min(3).max(800).describe('Descrizione dell\'immagine (inglese consigliato per qualità migliore)'),
    model:      z.enum(Object.keys(IMAGE_MODELS)).default('flux-dev').describe('Modello da usare'),
    ratio:      z.enum(['1:1', '16:9', '9:16', '4:3']).default('1:1').describe('Proporzioni'),
    resolution: z.enum(['512', '1024', '1440']).default('1024').describe('Risoluzione lato lungo'),
    negative:   z.string().max(400).optional().describe('Negative prompt (cosa evitare)'),
  },
  async ({ prompt, model, ratio, resolution, negative }) => {
    const cr = imageCredits(model)
    const profile = await getProfile()
    if (profile.credits < cr) {
      return { content: [{ type: 'text', text: `⚡ Crediti insufficienti: hai ${profile.credits}cr, servono ${cr}cr. Ricarica su https://frame-studio-ai.com/pricing` }], isError: true }
    }

    const data = await edgeFn('generate-image', { prompt, model, ratio, resolution, negative }, ANON_KEY)
    if (data.error) throw new Error(data.error)

    // La funzione può rispondere 'queued' (asincrona, richiede polling)
    // oppure 'success' con l'output diretto
    let url = null
    if (data.status === 'queued' && data.id) {
      const s = await getSession()
      for (let i = 0; i < 75 && !url; i++) {
        await new Promise(r => setTimeout(r, 4000))
        const d = await edgeFn('poll-image', { requestId: data.id, modelId: data.modelId }, s.token)
        if (d.error) throw new Error(d.error)
        if (d.done && d.output?.[0]) url = d.output[0]
      }
      if (!url) throw new Error('Timeout generazione immagine — riprova')
    } else if (data.status === 'success' && data.output?.[0]) {
      url = data.output[0]
    } else throw new Error(data.error ?? 'Generazione immagine fallita')

    await saveGeneration(url, { type: 'image', prompt, model, aspectRatio: ratio, creditsUsed: cr })
    await consumeCredits(cr)

    return { content: [{ type: 'text', text: `🖼 Immagine pronta!\nURL: ${url}\nCrediti usati: ${cr} (rimanenti: ~${profile.credits - cr})` }] }
  }
)

// TOOL: genera video
server.tool(
  'frameai_generate_video',
  'Genera un video AI con FrameAI (richiede 1-10 minuti). Usa i crediti dell\'account. Restituisce l\'URL del video (valido 24h, va scaricato). Per animare un\'immagine esistente passa image_url.',
  {
    prompt:       z.string().min(3).max(1500).describe('Descrizione della scena (inglese consigliato). Includi stile, camera, atmosfera.'),
    model:        z.enum(Object.keys(VIDEO_MODELS)).default('ltx-2').describe('Modello video. ltx-2 economico per test; kling-3.0/seedance-2.0 per qualità cinematografica'),
    aspect_ratio: z.enum(['16:9', '9:16', '1:1']).default('16:9').describe('Proporzioni (9:16 per social verticali)'),
    duration:     z.number().int().min(4).max(15).default(5).describe('Durata in secondi (limite dipende dal piano)'),
    resolution:   z.enum(['720p', '1080p', '4k']).default('720p').describe('4K solo per modelli Seedance'),
    image_url:    z.string().url().optional().describe('URL immagine di partenza per image-to-video (opzionale)'),
  },
  async ({ prompt, model, aspect_ratio, duration, resolution, image_url }, extra) => {
    // Validazioni locali
    if (resolution === '4k' && !FOURK_MODELS.has(model)) {
      return { content: [{ type: 'text', text: `Il 4K è supportato solo da: ${[...FOURK_MODELS].join(', ')}. Scegli 720p/1080p oppure un modello Seedance.` }], isError: true }
    }
    const cr = videoCredits(model, duration, resolution)
    const profile = await getProfile()
    if (profile.credits < cr) {
      return { content: [{ type: 'text', text: `⚡ Crediti insufficienti: hai ${profile.credits}cr, servono ${cr}cr per ${model} ${duration}s ${resolution}. Ricarica su https://frame-studio-ai.com/pricing` }], isError: true }
    }

    // Avvia il job in background e rispondi subito (evita il timeout MCP)
    const job = newJob('video', prompt.slice(0, 60))
    ;(async () => {
      try {
        const notify = jobNotifier(job)
        const url = await generateOneVideo({
          prompt, model, aspectRatio: aspect_ratio, duration, resolution,
          imageUrl: image_url, notify, progFrom: 5, progTo: 95, label: `Rendering ${model}`,
        })
        await saveGeneration(url, { type: 'video', prompt, model, aspectRatio: aspect_ratio, creditsUsed: cr })
        await consumeCredits(cr)
        job.status = 'done'; job.progress = 100
        job.result = `🎬 Video pronto!\nURL (valido 24h, scaricalo): ${url}\nModello: ${model} · ${duration}s · ${resolution} · ${aspect_ratio}\nCrediti usati: ${cr}`
      } catch (e) {
        job.status = 'error'; job.error = e instanceof Error ? e.message : String(e)
      }
    })()

    const estMin = model === 'ltx-2' ? 2 : 4
    return {
      content: [{
        type: 'text',
        text: `🎬 Generazione avviata in background!\njob_id: ${job.id}\nModello: ${model} · ${duration}s · ${resolution} · crediti previsti: ${cr}\nTempo stimato: ~${estMin} minuti.\n\nControlla lo stato con frameai_check_job (job_id: "${job.id}") tra 1-2 minuti.`,
      }],
    }
  }
)

// TOOL: genera FILM multi-scena (Regia AI)
server.tool(
  'frameai_generate_film',
  'Genera un FILM multi-scena completo con la Regia AI di FrameAI: la storia viene divisa in scene da un regista AI, ogni scena viene generata come clip video e il tutto viene montato in un unico film. Richiede 5-30 minuti. Restituisce l\'URL del film montato (valido 24h).',
  {
    story:        z.string().min(10).max(2000).describe('La storia o l\'idea del film (italiano o inglese). Es: "Un samurai attraversa il deserto in cerca del fratello, scontro finale al tramonto"'),
    scenes:       z.number().int().min(2).max(5).default(3).describe('Numero di scene del film'),
    model:        z.enum(Object.keys(VIDEO_MODELS)).default('ltx-2').describe('Modello per tutte le scene. ltx-2 economico; kling-3.0/seedance-2.0 per qualità cinema'),
    aspect_ratio: z.enum(['16:9', '9:16', '1:1']).default('16:9').describe('Proporzioni del film'),
    duration:     z.number().int().min(4).max(10).default(5).describe('Durata di ogni scena in secondi'),
    resolution:   z.enum(['720p', '1080p']).default('720p').describe('Risoluzione delle clip'),
  },
  async ({ story, scenes, model, aspect_ratio, duration, resolution }) => {
    // Costo totale: N scene + 2cr per il montaggio
    const MERGE_CREDITS = 2
    const totalCr = scenes * videoCredits(model, duration, resolution) + MERGE_CREDITS
    const profile = await getProfile()
    if (profile.credits < totalCr) {
      return { content: [{ type: 'text', text: `⚡ Crediti insufficienti: hai ${profile.credits}cr, servono ~${totalCr}cr per un film di ${scenes} scene con ${model}. Ricarica su https://frame-studio-ai.com/pricing` }], isError: true }
    }

    // Avvia il film in background e rispondi subito (evita il timeout MCP)
    const job = newJob('film', story.slice(0, 60))
    ;(async () => {
      try {
        const notify = jobNotifier(job)

        // 1) Regia AI: dividi la storia in scene con prompt cinematografici
        await notify(2, '🎬 La Regia AI sta scrivendo la sceneggiatura...')
        const s = await getSession()
        let shots = []
        try {
          const plan = await edgeFn('optimize-prompt', {
            useCase: 'flow-director',
            prompt: `${story}\n\n(Genera esattamente ${scenes} shot.)`,
          }, s.token)
          const text = plan.optimized ?? ''
          const match = text.match(/\{[\s\S]*\}/)
          if (match) {
            const parsed = JSON.parse(match[0])
            if (Array.isArray(parsed.shots) && parsed.shots.length) {
              shots = parsed.shots.slice(0, scenes).map((sh, i) => ({
                label: sh.label ?? `Scena ${i + 1}`,
                prompt: sh.prompt ?? story,
              }))
            }
          }
        } catch { /* fallback sotto */ }

        // Fallback: scene semplici se la Regia AI non risponde in formato valido
        if (shots.length === 0) {
          shots = Array.from({ length: scenes }, (_, i) => ({
            label: `Scena ${i + 1}`,
            prompt: `${story}. Scene ${i + 1} of ${scenes}, cinematic, consistent characters and style.`,
          }))
        }

        // 2) Genera le clip in sequenza
        const clipUrls = []
        for (let i = 0; i < shots.length; i++) {
          const progFrom = 5 + Math.round((i / shots.length) * 80)
          const progTo   = 5 + Math.round(((i + 1) / shots.length) * 80)
          await notify(progFrom, `🎥 ${shots[i].label} (${i + 1}/${shots.length})...`)
          const url = await generateOneVideo({
            prompt: shots[i].prompt, model, aspectRatio: aspect_ratio, duration, resolution,
            notify, progFrom, progTo, label: shots[i].label,
          })
          clipUrls.push(url)
        }

        // 3) Montaggio finale
        await notify(88, '✂️ Montaggio del film...')
        const merged = await edgeFn('merge-videos', { videoUrls: clipUrls }, ANON_KEY)
        const filmUrl = merged.outputUrl
        if (!filmUrl) throw new Error(merged.error ?? 'Montaggio fallito')

        // 4) Crediti + storico
        await saveGeneration(filmUrl, { type: 'video', prompt: `[FILM ${shots.length} scene] ${story.slice(0, 120)}`, model, aspectRatio: aspect_ratio, creditsUsed: totalCr })
        await consumeCredits(totalCr)

        const sceneList = shots.map((sh, i) => `  ${i + 1}. ${sh.label}: ${clipUrls[i]}`).join('\n')
        job.status = 'done'; job.progress = 100
        job.result = `🎬 FILM PRONTO! (${shots.length} scene · ${shots.length * duration}s totali · ${model})\n\n▶ Film montato (valido 24h, scaricalo):\n${filmUrl}\n\nClip singole:\n${sceneList}\n\nCrediti usati: ${totalCr}`
      } catch (e) {
        job.status = 'error'; job.error = e instanceof Error ? e.message : String(e)
      }
    })()

    const estMin = scenes * (model === 'ltx-2' ? 2 : 4) + 3
    return {
      content: [{
        type: 'text',
        text: `🎬 FILM AVVIATO! La Regia AI è al lavoro in background.\njob_id: ${job.id}\n${scenes} scene · ${model} · ${resolution} · crediti previsti: ${totalCr}\nTempo stimato: ~${estMin} minuti.\n\nControlla lo stato con frameai_check_job (job_id: "${job.id}") tra qualche minuto.`,
      }],
    }
  }
)

// TOOL: stato dei job in background
server.tool(
  'frameai_check_job',
  'Controlla lo stato di una generazione video/film avviata in background. Restituisce il progresso oppure il risultato finale con gli URL.',
  { job_id: z.string().describe('Il job_id restituito da frameai_generate_video o frameai_generate_film') },
  async ({ job_id }) => {
    const job = JOBS.get(job_id)
    if (!job) {
      return { content: [{ type: 'text', text: `Job "${job_id}" non trovato (il server potrebbe essere stato riavviato). Controlla le ultime generazioni con frameai_get_history.` }], isError: true }
    }
    const elapsed = Math.round((Date.now() - job.startedAt) / 1000)
    if (job.status === 'done')  return { content: [{ type: 'text', text: job.result }] }
    if (job.status === 'error') return { content: [{ type: 'text', text: `❌ Job fallito dopo ${elapsed}s: ${job.error}` }], isError: true }
    return { content: [{ type: 'text', text: `⏳ In lavorazione (${elapsed}s trascorsi)\nProgresso: ${job.progress}% — ${job.message}\n\nRicontrolla tra 1-2 minuti con frameai_check_job.` }] }
  }
)

// TOOL: storico generazioni
server.tool(
  'frameai_get_history',
  'Mostra le ultime generazioni (video/immagini) dell\'account FrameAI con i relativi URL.',
  { limit: z.number().int().min(1).max(20).default(5).describe('Quante generazioni recenti mostrare') },
  async ({ limit }) => {
    const s = await getSession()
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/generations?user_id=eq.${s.userId}&select=type,prompt,model,video_url,created_at&order=created_at.desc&limit=${limit}`,
      { headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${s.token}` } }
    )
    const rows = await res.json()
    if (!Array.isArray(rows) || rows.length === 0) {
      return { content: [{ type: 'text', text: 'Nessuna generazione trovata.' }] }
    }
    const lines = rows.map(r =>
      `- [${r.type}] ${new Date(r.created_at).toLocaleString('it-IT')} · ${r.model}\n  "${(r.prompt ?? '').slice(0, 80)}"\n  ${r.video_url ?? '(url scaduto)'}`
    ).join('\n')
    return { content: [{ type: 'text', text: `Ultime ${rows.length} generazioni:\n${lines}` }] }
  }
)

// ── Avvio ────────────────────────────────────────────────────
const transport = new StdioServerTransport()
await server.connect(transport)
console.error('[frameai-mcp] Server avviato — tools: get_credits, list_models, generate_image, generate_video, generate_film, check_job, get_history')
