# FrameAI MCP — Genera video e immagini AI dentro Claude

Collega il tuo account [FrameAI Studio](https://frame-studio-ai.com) a Claude Desktop:
chatti con Claude e generi video, immagini e film direttamente in conversazione,
usando i tuoi crediti FrameAI.

## Cosa puoi fare

| Tool | Cosa fa |
|---|---|
| `frameai_generate_film` | 🎬 **Regia AI**: storia → film multi-scena montato, con sceneggiatura scritta dall'AI |
| `frameai_generate_video` | Genera un video AI (Kling, Seedance, Veo...) da testo o da un'immagine |
| `frameai_generate_image` | Genera un'immagine AI (FLUX, Nano Banana, Seedream...) |
| `frameai_get_credits` | Mostra crediti rimanenti e piano attivo |
| `frameai_list_models` | Elenca modelli disponibili con costi |
| `frameai_get_history` | Le tue ultime generazioni con URL |

Esempi di cosa scrivere a Claude:
- *"Fammi un film di 3 scene: un samurai attraversa il deserto in cerca del fratello"*
- *"Genera un video di un drago che vola sulle Dolomiti al tramonto, stile cinematografico"*
- *"Crea un'immagine di un guerriero in armatura, poi animala con Kling"*
- *"Quanti crediti mi restano su FrameAI?"*

## Requisiti

- [Node.js 18+](https://nodejs.org) installato
- Un account FrameAI ([registrati gratis](https://frame-studio-ai.com/register) — 15 crediti inclusi)
- Claude Desktop

## Installazione

**1.** Scarica questa cartella (`mcp-server`) sul tuo computer, poi da terminale:

```bash
cd percorso/della/cartella/mcp-server
npm install
```

**2.** Apri il file di configurazione di Claude Desktop:

- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

**3.** Aggiungi il blocco `frameai` (crea il file se non esiste):

```json
{
  "mcpServers": {
    "frameai": {
      "command": "node",
      "args": ["C:\\percorso\\completo\\mcp-server\\index.js"],
      "env": {
        "FRAMEAI_SUPABASE_URL": "https://vyngrcrudvxoxbehwrqv.supabase.co",
        "FRAMEAI_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0",
        "FRAMEAI_EMAIL": "la-tua-email@esempio.com",
        "FRAMEAI_PASSWORD": "la-tua-password-frameai"
      }
    }
  }
}
```

> `FRAMEAI_SUPABASE_URL` e `FRAMEAI_ANON_KEY` sono valori pubblici forniti da FrameAI
> (li trovi nella pagina Plugin del sito). Email e password sono quelle del tuo account.

**4.** Riavvia Claude Desktop. Vedrai l'icona degli strumenti MCP: chiedi a Claude
*"quanti crediti ho su FrameAI?"* per verificare che tutto funzioni.

## Note

- I video richiedono 1-10 minuti di generazione: Claude aspetta e ti consegna l'URL a fine rendering.
- Gli URL dei video scadono dopo **24 ore**: scarica subito ciò che vuoi conservare.
- I costi in crediti sono identici a quelli del sito (usa `frameai_list_models` per vederli).
- I modelli disponibili dipendono dal tuo piano (Free → Agency), come sul sito.

## Sicurezza

La password resta **solo sul tuo computer**, nel file di config locale di Claude Desktop.
Il server MCP la usa esclusivamente per autenticarsi con FrameAI (Supabase Auth) —
nessun dato passa da server terzi.
