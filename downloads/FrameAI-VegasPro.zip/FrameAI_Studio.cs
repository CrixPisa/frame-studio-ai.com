// ============================================================
// FrameAI Studio — Script per VEGAS Pro (C# / .NET)
// Installazione: copia FrameAI_Studio.cs + FrameAI_Studio.cs.config
// in "Documenti\Vegas Script Menu", poi Tools -> Scripting -> Rescan
// ============================================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using ScriptPortal.Vegas;   // VEGAS Pro 14+. Per Sony Vegas <=13: using Sony.Vegas;

public class EntryPoint
{
    public void FromVegas(Vegas vegas)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        Application.EnableVisualStyles();
        using (FrameAIForm form = new FrameAIForm(vegas))
        {
            form.ShowDialog();
        }
    }
}

public class FrameAIForm : Form
{
    // ── CONFIGURAZIONE ──────────────────────────────────────
    const string SUPABASE_URL = "https://vyngrcrudvxoxbehwrqv.supabase.co";
    const string SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0";

    const int POLL_INTERVAL_MS = 6000;
    const int MAX_POLLS = 200;

    static readonly string[] MODEL_LABELS = {
        "LTX-2 (Free)", "Seedance 1.5 (Starter)", "Seedance Fast (Starter)",
        "Wan 2.6 (Starter)", "Kling 3.0 (Creator)", "Seedance 2.0 (Creator)",
        "Sora 2 (Business)", "Veo 3.1 (Agency)" };
    static readonly string[] MODEL_VALUES = {
        "ltx-2", "seedance-1.5", "seedance-fast", "wan-2.6",
        "kling-3.0", "seedance-2.0", "sora-2", "veo-3.1" };
    static readonly double[] MODEL_COST_PER_SEC = {
        0.004, 0.052, 0.242, 0.100, 0.140, 0.303, 0.150, 0.200 };

    static readonly string[] IMG_MODEL_LABELS = {
        "Flux Schnell (Free)", "Flux Dev (Starter)", "Flux 2 (Starter)",
        "Nano Banana 2 (Creator)", "Nano Banana Pro (Business)", "Seedream (Starter)" };
    static readonly string[] IMG_MODEL_VALUES = {
        "flux-schnell", "flux-dev", "flux2", "nano-banana-2", "nano-banana-pro", "seedream" };
    static readonly int[] IMG_MODEL_CREDITS = { 1, 1, 2, 2, 3, 1 };

    // Tools: id, label, categoria (image/video), crediti, serve prompt
    static readonly string[] TOOL_IDS      = { "upscale-image","enhance-photo","remove-bg","remove-object","upscale-video","remove-bg-video","remove-object-video" };
    static readonly string[] TOOL_LABELS   = { "🔍 Upscale Immagine (1cr)","✨ Migliora Foto AI (2cr)","✂️ Rimuovi Sfondo (1cr)","🧹 Rimuovi Oggetto (3cr)","🎞 Upscale Video (4cr)","✂️ Rimuovi Sfondo Video (6cr)","🧹 Rimuovi Oggetto Video (8cr)" };
    static readonly string[] TOOL_CATS     = { "image","image","image","image","video","video","video" };
    static readonly int[]    TOOL_CREDITS  = { 1, 2, 1, 3, 4, 6, 8 };
    static readonly bool[]   TOOL_PROMPT   = { false, false, false, true, false, false, true };

    Vegas vegas;
    JavaScriptSerializer json = new JavaScriptSerializer();
    string accessToken, userId;
    BackgroundWorker bw;

    // ── Tab controls ────────────────────────────────────────
    TabControl tabs;
    TabPage tabVideo, tabImage, tabTools;

    // ── Video controls ───────────────────────────────────────
    TextBox emailBox, passBox;
    TextBox promptBox;
    ComboBox modelCombo, ratioCombo, durationCombo, resCombo;
    CheckBox autoImportCheck, addToTimelineCheck;
    Button loginBtn, generateBtn;

    // ── Image controls ───────────────────────────────────────
    TextBox imgPromptBox;
    ComboBox imgModelCombo, imgRatioCombo;
    CheckBox imgImportCheck, imgAddToTimelineCheck;
    Button imgGenerateBtn;
    Label imgCostLbl;

    // ── Tools controls ───────────────────────────────────────
    ComboBox toolCombo;
    TextBox toolPromptBox;
    Label toolPromptLbl, toolHintLbl, toolFileLbl;
    Button toolFileBtn, toolRunBtn;
    CheckBox toolImportCheck, toolAddToTimelineCheck;

    // ── Shared ───────────────────────────────────────────────
    Label statusLbl, creditsLbl, costLbl;
    ProgressBar progressBar;
    Panel loginPanel, genPanel;
    string toolFilePath = null;

    public FrameAIForm(Vegas vegas)
    {
        this.vegas = vegas;
        BuildUi();
        if (SUPABASE_URL.Contains("INSERISCI"))
        {
            loginPanel.Enabled = false;
            statusLbl.Text = "⚠️ Apri FrameAI_Studio.cs e compila SUPABASE_URL e SUPABASE_ANON_KEY.";
        }
    }

    void BuildUi()
    {
        Text = "FrameAI Studio · VEGAS Pro";
        Size = new Size(440, 680);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        BackColor = Color.FromArgb(13, 15, 20);
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 9F);

        creditsLbl = MakeLabel("", 12, 10, 400);
        creditsLbl.ForeColor = Color.Orange;
        Controls.Add(creditsLbl);

        // ── Login panel ─────────────────────────────────────
        loginPanel = new Panel { Location = new Point(12, 40), Size = new Size(400, 140) };
        loginPanel.Controls.Add(MakeLabel("Email", 0, 0, 200));
        emailBox = MakeText(0, 18, 400); loginPanel.Controls.Add(emailBox);
        loginPanel.Controls.Add(MakeLabel("Password", 0, 52, 200));
        passBox = MakeText(0, 70, 400); passBox.UseSystemPasswordChar = true;
        loginPanel.Controls.Add(passBox);
        loginBtn = MakeButton("Accedi", 0, 104, 400);
        loginBtn.Click += OnLogin;
        loginPanel.Controls.Add(loginBtn);
        Controls.Add(loginPanel);

        // ── Generator panel (con tab) ────────────────────────
        genPanel = new Panel { Location = new Point(12, 40), Size = new Size(400, 560), Visible = false };

        tabs = new TabControl {
            Location = new Point(0, 0), Size = new Size(400, 520),
            Appearance = TabAppearance.Normal,
        };
        tabs.DrawMode = TabDrawMode.OwnerDrawFixed;
        tabs.DrawItem += DrawTabItem;
        tabs.ItemSize = new Size(120, 28);

        tabVideo = new TabPage("🎬 Video") { BackColor = Color.FromArgb(13, 15, 20), ForeColor = Color.White };
        tabImage = new TabPage("🖼 Immagine") { BackColor = Color.FromArgb(13, 15, 20), ForeColor = Color.White };
        tabTools = new TabPage("🔧 Tools") { BackColor = Color.FromArgb(13, 15, 20), ForeColor = Color.White };
        tabs.TabPages.AddRange(new TabPage[] { tabVideo, tabImage, tabTools });
        genPanel.Controls.Add(tabs);

        BuildVideoTab();
        BuildImageTab();
        BuildToolsTab();

        progressBar = new ProgressBar { Location = new Point(0, 525), Size = new Size(400, 10), Visible = false };
        genPanel.Controls.Add(progressBar);
        Controls.Add(genPanel);

        statusLbl = MakeLabel("", 12, 608, 400);
        statusLbl.Height = 50;
        Controls.Add(statusLbl);
    }

    void DrawTabItem(object sender, DrawItemEventArgs e)
    {
        var tab = tabs.TabPages[e.Index];
        bool selected = e.Index == tabs.SelectedIndex;
        e.Graphics.FillRectangle(new SolidBrush(selected ? Color.FromArgb(168, 85, 247) : Color.FromArgb(26, 30, 41)), e.Bounds);
        var tf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        e.Graphics.DrawString(tab.Text, Font, new SolidBrush(selected ? Color.White : Color.FromArgb(139, 144, 160)), e.Bounds, tf);
    }

    void BuildVideoTab()
    {
        int y = 8;
        tabVideo.Controls.Add(MakeLabel("Prompt", 4, y, 200));
        promptBox = MakeText(4, y + 16, 388); promptBox.Multiline = true; promptBox.Height = 70;
        tabVideo.Controls.Add(promptBox);
        y += 96;

        tabVideo.Controls.Add(MakeLabel("Modello", 4, y, 120));
        modelCombo = MakeCombo(4, y + 16, 230, MODEL_LABELS); modelCombo.SelectedIndex = 3;
        tabVideo.Controls.Add(modelCombo);
        tabVideo.Controls.Add(MakeLabel("Formato", 245, y, 100));
        ratioCombo = MakeCombo(245, y + 16, 147, new string[] { "16:9", "9:16", "1:1", "21:9", "4:3" });
        tabVideo.Controls.Add(ratioCombo);
        y += 50;

        tabVideo.Controls.Add(MakeLabel("Durata", 4, y, 100));
        durationCombo = MakeCombo(4, y + 16, 110, new string[] { "5s", "8s", "10s", "15s" });
        tabVideo.Controls.Add(durationCombo);
        tabVideo.Controls.Add(MakeLabel("Risoluzione", 125, y, 100));
        resCombo = MakeCombo(125, y + 16, 110, new string[] { "720p", "1080p" });
        tabVideo.Controls.Add(resCombo);
        costLbl = MakeLabel("", 250, y + 18, 140); costLbl.ForeColor = Color.Orange;
        tabVideo.Controls.Add(costLbl);
        y += 50;

        autoImportCheck = new CheckBox { Text = "Aggiungi al Project Media", Checked = true, Location = new Point(4, y), Width = 390, ForeColor = Color.Gainsboro };
        tabVideo.Controls.Add(autoImportCheck);
        addToTimelineCheck = new CheckBox { Text = "Inserisci anche in timeline (al cursore)", Checked = false, Location = new Point(4, y + 22), Width = 390, ForeColor = Color.Gainsboro };
        tabVideo.Controls.Add(addToTimelineCheck);
        y += 52;

        generateBtn = MakeButton("🎬 Genera video", 4, y, 388);
        generateBtn.Click += OnGenerate;
        tabVideo.Controls.Add(generateBtn);

        EventHandler upd = delegate { UpdateVideoCost(); };
        modelCombo.SelectedIndexChanged += upd;
        durationCombo.SelectedIndexChanged += upd;
        resCombo.SelectedIndexChanged += upd;
        UpdateVideoCost();
    }

    void BuildImageTab()
    {
        int y = 8;
        tabImage.Controls.Add(MakeLabel("Prompt", 4, y, 200));
        imgPromptBox = MakeText(4, y + 16, 388); imgPromptBox.Multiline = true; imgPromptBox.Height = 70;
        tabImage.Controls.Add(imgPromptBox);
        y += 96;

        tabImage.Controls.Add(MakeLabel("Modello", 4, y, 120));
        imgModelCombo = MakeCombo(4, y + 16, 230, IMG_MODEL_LABELS); imgModelCombo.SelectedIndex = 1;
        tabImage.Controls.Add(imgModelCombo);
        tabImage.Controls.Add(MakeLabel("Formato", 245, y, 100));
        imgRatioCombo = MakeCombo(245, y + 16, 147, new string[] { "1:1", "16:9", "9:16", "4:3" });
        tabImage.Controls.Add(imgRatioCombo);
        y += 50;

        imgCostLbl = MakeLabel("", 4, y, 200); imgCostLbl.ForeColor = Color.Orange;
        tabImage.Controls.Add(imgCostLbl);
        y += 20;

        imgImportCheck = new CheckBox { Text = "Aggiungi al Project Media", Checked = true, Location = new Point(4, y), Width = 390, ForeColor = Color.Gainsboro };
        tabImage.Controls.Add(imgImportCheck);
        imgAddToTimelineCheck = new CheckBox { Text = "Inserisci anche in timeline (al cursore)", Checked = false, Location = new Point(4, y + 22), Width = 390, ForeColor = Color.Gainsboro };
        tabImage.Controls.Add(imgAddToTimelineCheck);
        y += 52;

        imgGenerateBtn = MakeButton("🖼 Genera immagine", 4, y, 388);
        imgGenerateBtn.Click += OnGenerateImage;
        tabImage.Controls.Add(imgGenerateBtn);

        imgModelCombo.SelectedIndexChanged += delegate { UpdateImageCost(); };
        UpdateImageCost();
    }

    void BuildToolsTab()
    {
        int y = 8;
        tabTools.Controls.Add(MakeLabel("Tool", 4, y, 200));
        toolCombo = MakeCombo(4, y + 16, 388, TOOL_LABELS);
        tabTools.Controls.Add(toolCombo);
        y += 46;

        toolHintLbl = MakeLabel("", 4, y, 388);
        toolHintLbl.ForeColor = Color.FromArgb(100, 110, 140);
        tabTools.Controls.Add(toolHintLbl);
        y += 18;

        toolPromptLbl = MakeLabel("Cosa rimuovere (in inglese)", 4, y, 388);
        toolPromptLbl.Visible = false;
        tabTools.Controls.Add(toolPromptLbl);
        toolPromptBox = MakeText(4, y + 16, 388);
        toolPromptBox.PlaceholderText = "the car, the person on the left...";
        toolPromptBox.Visible = false;
        tabTools.Controls.Add(toolPromptBox);
        y += 48;

        tabTools.Controls.Add(MakeLabel("File da elaborare", 4, y, 200));
        toolFileBtn = MakeButton("📁 Scegli file...", 4, y + 16, 180);
        toolFileBtn.BackColor = Color.FromArgb(35, 40, 56);
        toolFileBtn.Click += OnPickToolFile;
        tabTools.Controls.Add(toolFileBtn);
        toolFileLbl = MakeLabel("", 195, y + 20, 195);
        tabTools.Controls.Add(toolFileLbl);
        y += 56;

        toolImportCheck = new CheckBox { Text = "Aggiungi al Project Media", Checked = true, Location = new Point(4, y), Width = 390, ForeColor = Color.Gainsboro };
        tabTools.Controls.Add(toolImportCheck);
        toolAddToTimelineCheck = new CheckBox { Text = "Inserisci anche in timeline (al cursore)", Checked = false, Location = new Point(4, y + 22), Width = 390, ForeColor = Color.Gainsboro };
        tabTools.Controls.Add(toolAddToTimelineCheck);
        y += 52;

        toolRunBtn = MakeButton("🔧 Elabora", 4, y, 388);
        toolRunBtn.Click += OnRunTool;
        tabTools.Controls.Add(toolRunBtn);

        toolCombo.SelectedIndexChanged += delegate { UpdateToolsUI(); };
        UpdateToolsUI();
    }

    // ── Helpers UI ──────────────────────────────────────────
    Label MakeLabel(string t, int x, int y, int w)
    { return new Label { Text = t, Location = new Point(x, y), Width = w, ForeColor = Color.FromArgb(139, 144, 160) }; }
    TextBox MakeText(int x, int y, int w)
    { return new TextBox { Location = new Point(x, y), Width = w,
        BackColor = Color.FromArgb(26, 30, 41), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle }; }
    ComboBox MakeCombo(int x, int y, int w, string[] items)
    { var c = new ComboBox { Location = new Point(x, y), Width = w, DropDownStyle = ComboBoxStyle.DropDownList,
        BackColor = Color.FromArgb(26, 30, 41), ForeColor = Color.White };
      c.Items.AddRange(items); c.SelectedIndex = 0; return c; }
    Button MakeButton(string t, int x, int y, int w)
    { return new Button { Text = t, Location = new Point(x, y), Width = w, Height = 34,
        BackColor = Color.FromArgb(168, 85, 247), ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; }

    // ── Costi ───────────────────────────────────────────────
    int VideoDuration() { return int.Parse(durationCombo.SelectedItem.ToString().TrimEnd('s')); }

    int VideoCreditCost()
    {
        double perSec = MODEL_COST_PER_SEC[modelCombo.SelectedIndex];
        double mult = resCombo.SelectedItem.ToString() == "1080p" ? 1.5 : 1.0;
        double usd = perSec * VideoDuration() * mult;
        return Math.Max(1, (int)Math.Ceiling(usd / 0.063));
    }

    void UpdateVideoCost() { costLbl.Text = "⚡ " + VideoCreditCost() + "cr"; }

    void UpdateImageCost()
    {
        int cr = imgModelCombo.SelectedIndex < IMG_MODEL_CREDITS.Length ? IMG_MODEL_CREDITS[imgModelCombo.SelectedIndex] : 1;
        imgCostLbl.Text = "⚡ " + cr + "cr";
    }

    void UpdateToolsUI()
    {
        int idx = toolCombo.SelectedIndex;
        if (idx < 0 || idx >= TOOL_IDS.Length) return;
        bool isVideo = TOOL_CATS[idx] == "video";
        bool needsPrompt = TOOL_PROMPT[idx];
        toolHintLbl.Text = "Input: " + (isVideo ? "video (mp4/mov)" : "immagine (png/jpg/webp)");
        toolPromptLbl.Visible = needsPrompt;
        toolPromptBox.Visible = needsPrompt;
        toolFilePath = null;
        toolFileLbl.Text = "";
    }

    // ── HTTP helpers ────────────────────────────────────────
    Dictionary<string, object> Post(string path, object payload, string bearer)
    {
        using (WebClient wc = new WebClient())
        {
            wc.Encoding = Encoding.UTF8;
            wc.Headers["Content-Type"] = "application/json";
            wc.Headers["apikey"] = SUPABASE_ANON_KEY;
            wc.Headers["Authorization"] = "Bearer " + bearer;
            try
            {
                string res = wc.UploadString(SUPABASE_URL + path, json.Serialize(payload));
                return json.Deserialize<Dictionary<string, object>>(res);
            }
            catch (WebException ex)
            {
                string body = "";
                if (ex.Response != null)
                    using (StreamReader r = new StreamReader(ex.Response.GetResponseStream()))
                        body = r.ReadToEnd();
                Dictionary<string, object> err = null;
                try { err = json.Deserialize<Dictionary<string, object>>(body); } catch { }
                string msg = err != null && err.ContainsKey("error") ? err["error"].ToString()
                    : err != null && err.ContainsKey("msg") ? err["msg"].ToString()
                    : err != null && err.ContainsKey("error_description") ? err["error_description"].ToString()
                    : ex.Message;
                throw new Exception(msg);
            }
        }
    }

    List<Dictionary<string, object>> GetRows(string path, string bearer)
    {
        using (WebClient wc = new WebClient())
        {
            wc.Headers["apikey"] = SUPABASE_ANON_KEY;
            wc.Headers["Authorization"] = "Bearer " + bearer;
            string res = wc.DownloadString(SUPABASE_URL + path);
            return json.Deserialize<List<Dictionary<string, object>>>(res);
        }
    }

    string UploadFile(string filePath)
    {
        byte[] fileBytes = File.ReadAllBytes(filePath);
        string boundary = "----FrameAIVegas" + Guid.NewGuid().ToString("N");
        string fname = Path.GetFileName(filePath);
        string ext = Path.GetExtension(filePath).ToLower();
        string mime = (ext == ".mp4" || ext == ".mov") ? "video/mp4"
                    : (ext == ".png") ? "image/png"
                    : "image/jpeg";

        var sb = new StringBuilder();
        sb.Append("--").Append(boundary).Append("\r\n");
        sb.Append("Content-Disposition: form-data; name=\"file\"; filename=\"").Append(fname).Append("\"\r\n");
        sb.Append("Content-Type: ").Append(mime).Append("\r\n\r\n");
        byte[] header = Encoding.UTF8.GetBytes(sb.ToString());
        byte[] footer = Encoding.UTF8.GetBytes("\r\n--" + boundary + "--\r\n");

        byte[] body = new byte[header.Length + fileBytes.Length + footer.Length];
        Array.Copy(header, 0, body, 0, header.Length);
        Array.Copy(fileBytes, 0, body, header.Length, fileBytes.Length);
        Array.Copy(footer, 0, body, header.Length + fileBytes.Length, footer.Length);

        using (WebClient wc = new WebClient())
        {
            wc.Headers["Content-Type"] = "multipart/form-data; boundary=" + boundary;
            wc.Headers["Authorization"] = "Bearer " + accessToken;
            wc.Headers["apikey"] = SUPABASE_ANON_KEY;
            byte[] res = wc.UploadData(SUPABASE_URL + "/functions/v1/upload-temp", "POST", body);
            var d = json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(res));
            if (!d.ContainsKey("url")) throw new Exception("Upload fallito");
            return d["url"].ToString();
        }
    }

    // ── Auth ────────────────────────────────────────────────
    void OnLogin(object s, EventArgs e)
    {
        try
        {
            var d = Post("/auth/v1/token?grant_type=password",
                new Dictionary<string, string> { { "email", emailBox.Text.Trim() }, { "password", passBox.Text } },
                SUPABASE_ANON_KEY);
            accessToken = d["access_token"].ToString();
            var user = (Dictionary<string, object>)d["user"];
            userId = user["id"].ToString();
            RefreshCredits();
            loginPanel.Visible = false;
            genPanel.Visible = true;
            statusLbl.Text = "";
        }
        catch (Exception ex) { statusLbl.Text = "Errore login: " + ex.Message; }
    }

    int GetCredits(out string plan)
    {
        var rows = GetRows("/rest/v1/profiles?id=eq." + userId + "&select=credits,plan", accessToken);
        if (rows.Count == 0) throw new Exception("Profilo non trovato");
        plan = rows[0]["plan"].ToString();
        return Convert.ToInt32(rows[0]["credits"]);
    }

    void RefreshCredits()
    {
        try { string plan; int c = GetCredits(out plan); creditsLbl.Text = "⚡ " + c + "cr · " + plan; }
        catch { }
    }

    // ── Import in VEGAS ─────────────────────────────────────
    void ImportFileIntoVegas(string filePath, bool addToTimeline)
    {
        var media = vegas.Project.MediaPool.AddMedia(filePath);
        if (addToTimeline && media != null)
        {
            // Cerca traccia video esistente
            VideoTrack track = null;
            foreach (Track t in vegas.Project.Tracks)
                if (t.IsVideo()) { track = (VideoTrack)t; break; }
            if (track == null) { track = new VideoTrack(); vegas.Project.Tracks.Add(track); }
            var start = vegas.Transport.CursorPosition;
            var ve = new VideoEvent(start, media.Length);
            track.Events.Add(ve);
            try { ve.AddTake(media.GetVideoStreamByIndex(0)); } catch { }
        }
    }

    string DownloadFile(string url, string prefix, string ext)
    {
        string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "FrameAI-Videos");
        Directory.CreateDirectory(dir);
        string filePath = Path.Combine(dir, prefix + "_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + "." + ext);
        using (WebClient wc = new WebClient()) { wc.DownloadFile(url, filePath); }
        return filePath;
    }

    // ════════════════════════════════════════════════════════
    // GENERA VIDEO
    // ════════════════════════════════════════════════════════
    void OnGenerate(object s, EventArgs e)
    {
        string prompt = promptBox.Text.Trim();
        if (prompt.Length == 0) { statusLbl.Text = "Scrivi un prompt prima di generare."; return; }

        int cost = VideoCreditCost();
        try
        {
            string plan; int credits = GetCredits(out plan);
            if (credits < cost) { statusLbl.Text = "Crediti insufficienti — hai " + credits + "cr, servono " + cost + "cr."; return; }
        }
        catch (Exception ex) { statusLbl.Text = "Errore: " + ex.Message; return; }

        var payload = new Dictionary<string, object> {
            { "prompt", prompt },
            { "model", MODEL_VALUES[modelCombo.SelectedIndex] },
            { "aspectRatio", ratioCombo.SelectedItem.ToString() },
            { "duration", VideoDuration() },
            { "resolution", resCombo.SelectedItem.ToString() } };

        generateBtn.Enabled = false;
        progressBar.Visible = true; progressBar.Value = 10;
        statusLbl.Text = "Avvio generazione video...";

        bw = new BackgroundWorker { WorkerReportsProgress = true };
        bw.DoWork += delegate (object o, DoWorkEventArgs ev) { ev.Result = RunVideoGeneration(payload, cost, bw); };
        bw.ProgressChanged += OnProgress;
        bw.RunWorkerCompleted += delegate (object o, RunWorkerCompletedEventArgs ev) { OnVideoDone(ev); };
        bw.RunWorkerAsync();
    }

    string RunVideoGeneration(Dictionary<string, object> payload, int cost, BackgroundWorker worker)
    {
        var job = Post("/functions/v1/generate-video", payload, accessToken);
        if (!job.ContainsKey("id") || !job.ContainsKey("modelId"))
            throw new Exception(job.ContainsKey("error") ? job["error"].ToString() : "Risposta non valida");
        string jobId = job["id"].ToString();
        string modelId = job["modelId"].ToString();

        string url = null;
        for (int i = 0; i < MAX_POLLS; i++)
        {
            var r = Post("/functions/v1/poll-video",
                new Dictionary<string, string> { { "requestId", jobId }, { "falEndpoint", modelId } },
                SUPABASE_ANON_KEY);

            if (r.ContainsKey("outputUrl") && r["outputUrl"] != null) url = r["outputUrl"].ToString();
            else if (r.ContainsKey("output") && r["output"] is object[] && ((object[])r["output"]).Length > 0)
                url = ((object[])r["output"])[0].ToString();

            double prog = r.ContainsKey("progress") && r["progress"] != null ? Convert.ToDouble(r["progress"]) : 0;
            worker.ReportProgress((int)Math.Min(95, 30 + prog * 0.65),
                prog > 0 ? "Rendering... " + (int)prog + "%" : "Rendering in corso...");

            bool done = (r.ContainsKey("done") && r["done"] != null && Convert.ToBoolean(r["done"]))
                || (r.ContainsKey("status") && (r["status"].ToString() == "success" || r["status"].ToString() == "COMPLETED"));
            if (done && url != null) break;
            if (r.ContainsKey("status") && r["status"].ToString() == "error")
                throw new Exception(r.ContainsKey("error") ? r["error"].ToString() : "Rendering fallito");

            System.Threading.Thread.Sleep(POLL_INTERVAL_MS);
        }
        if (url == null) throw new Exception("Timeout — riprova con durata minore.");

        try { Post("/functions/v1/consume-credits",
            new Dictionary<string, object> { { "userId", userId }, { "amount", cost } }, accessToken); } catch { }
        try { Post("/functions/v1/save-generation",
            new Dictionary<string, object> { { "userId", userId }, { "fileUrl", url }, { "type", "video" },
                { "prompt", payload["prompt"] }, { "model", payload["model"] },
                { "aspectRatio", payload["aspectRatio"] }, { "creditsUsed", cost } }, accessToken); } catch { }

        worker.ReportProgress(97, "Download del video...");
        return DownloadFile(url, "frameai", "mp4");
    }

    void OnVideoDone(RunWorkerCompletedEventArgs e)
    {
        generateBtn.Enabled = true;
        progressBar.Visible = false;
        if (e.Error != null) { statusLbl.Text = "Errore: " + e.Error.Message; return; }
        string filePath = (string)e.Result;
        try
        {
            if (autoImportCheck.Checked) ImportFileIntoVegas(filePath, addToTimelineCheck.Checked);
            RefreshCredits();
            statusLbl.Text = "✅ Video pronto: " + filePath;
        }
        catch (Exception ex) { statusLbl.Text = "Scaricato in " + filePath + " ma import fallito: " + ex.Message; }
    }

    // ════════════════════════════════════════════════════════
    // GENERA IMMAGINE
    // ════════════════════════════════════════════════════════
    void OnGenerateImage(object s, EventArgs e)
    {
        string prompt = imgPromptBox.Text.Trim();
        if (prompt.Length == 0) { statusLbl.Text = "Scrivi un prompt prima di generare."; return; }

        int idx = imgModelCombo.SelectedIndex;
        int cost = idx < IMG_MODEL_CREDITS.Length ? IMG_MODEL_CREDITS[idx] : 1;
        try
        {
            string plan; int credits = GetCredits(out plan);
            if (credits < cost) { statusLbl.Text = "Crediti insufficienti — hai " + credits + "cr, servono " + cost + "cr."; return; }
        }
        catch (Exception ex) { statusLbl.Text = "Errore: " + ex.Message; return; }

        var payload = new Dictionary<string, object> {
            { "prompt", prompt },
            { "model", IMG_MODEL_VALUES[idx] },
            { "ratio", imgRatioCombo.SelectedItem.ToString() },
            { "resolution", "1024" } };

        imgGenerateBtn.Enabled = false;
        progressBar.Visible = true; progressBar.Value = 10;
        statusLbl.Text = "Generazione immagine...";

        var bwImg = new BackgroundWorker { WorkerReportsProgress = true };
        bwImg.DoWork += delegate (object o, DoWorkEventArgs ev) { ev.Result = RunImageGeneration(payload, cost, bwImg); };
        bwImg.ProgressChanged += OnProgress;
        bwImg.RunWorkerCompleted += delegate (object o, RunWorkerCompletedEventArgs ev) {
            imgGenerateBtn.Enabled = true;
            progressBar.Visible = false;
            if (ev.Error != null) { statusLbl.Text = "Errore: " + ev.Error.Message; return; }
            string fp = (string)ev.Result;
            try
            {
                if (imgImportCheck.Checked) ImportFileIntoVegas(fp, imgAddToTimelineCheck.Checked);
                RefreshCredits();
                statusLbl.Text = "✅ Immagine pronta: " + fp;
            }
            catch (Exception ex) { statusLbl.Text = "Scaricata in " + fp + " ma import fallito: " + ex.Message; }
        };
        bwImg.RunWorkerAsync();
    }

    string RunImageGeneration(Dictionary<string, object> payload, int cost, BackgroundWorker worker)
    {
        worker.ReportProgress(20, "Generazione immagine...");
        var data = Post("/functions/v1/generate-image", payload, accessToken);
        if (data.ContainsKey("error")) throw new Exception(data["error"].ToString());
        string url = null;
        if (data.ContainsKey("output"))
        {
            var arr = data["output"] as object[];
            if (arr != null && arr.Length > 0) url = arr[0].ToString();
        }
        if (url == null && data.ContainsKey("imageUrl")) url = data["imageUrl"].ToString();
        if (url == null && data.ContainsKey("url")) url = data["url"].ToString();
        if (url == null) throw new Exception("Nessuna immagine restituita dal server");

        try { Post("/functions/v1/consume-credits",
            new Dictionary<string, object> { { "userId", userId }, { "amount", cost } }, accessToken); } catch { }
        try { Post("/functions/v1/save-generation",
            new Dictionary<string, object> { { "userId", userId }, { "fileUrl", url }, { "type", "image" },
                { "prompt", payload["prompt"] }, { "model", payload["model"] }, { "creditsUsed", cost } }, accessToken); } catch { }

        worker.ReportProgress(90, "Download immagine...");
        return DownloadFile(url, "frameai_img", "jpg");
    }

    // ════════════════════════════════════════════════════════
    // TOOLS
    // ════════════════════════════════════════════════════════
    void OnPickToolFile(object s, EventArgs e)
    {
        int idx = toolCombo.SelectedIndex;
        bool isVideo = idx < TOOL_CATS.Length && TOOL_CATS[idx] == "video";
        string filter = isVideo
            ? "Video|*.mp4;*.mov;*.webm;*.avi|Tutti i file|*.*"
            : "Immagini|*.png;*.jpg;*.jpeg;*.webp;*.exr;*.tif;*.tiff|Tutti i file|*.*";
        using (var dlg = new OpenFileDialog { Filter = filter })
        {
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                toolFilePath = dlg.FileName;
                toolFileLbl.Text = "✓ " + Path.GetFileName(dlg.FileName);
            }
        }
    }

    void OnRunTool(object s, EventArgs e)
    {
        if (toolFilePath == null || !File.Exists(toolFilePath))
        { statusLbl.Text = "Scegli un file da elaborare."; return; }

        int idx = toolCombo.SelectedIndex;
        if (idx < 0 || idx >= TOOL_IDS.Length) return;

        string toolId = TOOL_IDS[idx];
        bool isVideo = TOOL_CATS[idx] == "video";
        int cost = TOOL_CREDITS[idx];
        bool needsPrompt = TOOL_PROMPT[idx];
        string prompt = needsPrompt ? toolPromptBox.Text.Trim() : null;
        if (needsPrompt && (prompt == null || prompt.Length == 0))
        { statusLbl.Text = "Scrivi cosa vuoi rimuovere."; return; }

        try
        {
            string plan; int credits = GetCredits(out plan);
            if (credits < cost) { statusLbl.Text = "Crediti insufficienti — hai " + credits + "cr, servono " + cost + "cr."; return; }
        }
        catch (Exception ex) { statusLbl.Text = "Errore: " + ex.Message; return; }

        string capturedFilePath = toolFilePath;
        toolRunBtn.Enabled = false;
        progressBar.Visible = true; progressBar.Value = 10;
        statusLbl.Text = "Upload del file...";

        var bwTool = new BackgroundWorker { WorkerReportsProgress = true };
        bwTool.DoWork += delegate (object o, DoWorkEventArgs ev) {
            ev.Result = RunTool(toolId, capturedFilePath, isVideo, cost, prompt, bwTool);
        };
        bwTool.ProgressChanged += OnProgress;
        bwTool.RunWorkerCompleted += delegate (object o, RunWorkerCompletedEventArgs ev) {
            toolRunBtn.Enabled = true;
            progressBar.Visible = false;
            if (ev.Error != null) { statusLbl.Text = "Errore: " + ev.Error.Message; return; }
            string fp = (string)ev.Result;
            try
            {
                if (toolImportCheck.Checked) ImportFileIntoVegas(fp, toolAddToTimelineCheck.Checked);
                RefreshCredits();
                statusLbl.Text = "✅ Risultato pronto: " + fp;
            }
            catch (Exception ex) { statusLbl.Text = "Salvato in " + fp + " ma import fallito: " + ex.Message; }
        };
        bwTool.RunWorkerAsync();
    }

    string RunTool(string toolId, string filePath, bool isVideo, int cost, string prompt, BackgroundWorker worker)
    {
        worker.ReportProgress(15, "Upload del file...");
        string fileUrl = UploadFile(filePath);

        worker.ReportProgress(35, "Elaborazione AI...");
        var payload = new Dictionary<string, object> {
            { "tool", toolId }, { "fileUrl", fileUrl },
            { "userId", userId }, { "credits", cost } };
        if (prompt != null) payload["bgPrompt"] = prompt;

        var resp = Post("/functions/v1/tools-process", payload, accessToken);
        if (resp.ContainsKey("error")) throw new Exception(resp["error"].ToString());

        string outUrl = resp.ContainsKey("outputUrl") && resp["outputUrl"] != null ? resp["outputUrl"].ToString() : null;

        // Polling asincrono se non abbiamo già l'output
        if (outUrl == null && resp.ContainsKey("jobId"))
        {
            string jobId = resp["jobId"].ToString();
            for (int i = 0; i < MAX_POLLS; i++)
            {
                System.Threading.Thread.Sleep(5000);
                var rows = GetRows("/rest/v1/tool_jobs?id=eq." + jobId + "&select=status,output_url,error_msg,fal_progress", accessToken);
                if (rows.Count == 0) continue;
                var st = rows[0];
                double prog = st.ContainsKey("fal_progress") && st["fal_progress"] != null ? Convert.ToDouble(st["fal_progress"]) : 0;
                worker.ReportProgress((int)Math.Min(92, 35 + prog * 0.55),
                    prog > 0 ? "Elaborazione... " + (int)prog + "%" : "Elaborazione in corso...");
                string status = st.ContainsKey("status") ? st["status"].ToString() : "";
                if (status == "done" && st.ContainsKey("output_url") && st["output_url"] != null)
                { outUrl = st["output_url"].ToString(); break; }
                if (status == "failed")
                    throw new Exception(st.ContainsKey("error_msg") && st["error_msg"] != null ? st["error_msg"].ToString() : "Elaborazione fallita");
            }
        }
        if (outUrl == null) throw new Exception("Timeout — nessun output dal tool.");

        try { Post("/functions/v1/consume-credits",
            new Dictionary<string, object> { { "userId", userId }, { "amount", cost } }, accessToken); } catch { }

        worker.ReportProgress(95, "Download del risultato...");
        string ext = isVideo ? "mp4" : (toolId == "remove-bg" ? "png" : "jpg");
        return DownloadFile(outUrl, "frameai_" + toolId, ext);
    }

    // ── Shared progress handler ──────────────────────────────
    void OnProgress(object o, ProgressChangedEventArgs ev)
    {
        progressBar.Value = Math.Min(100, ev.ProgressPercentage);
        statusLbl.Text = (string)ev.UserState;
    }
}
