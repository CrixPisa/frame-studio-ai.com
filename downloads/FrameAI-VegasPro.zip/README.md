# FrameAI Studio — Script per VEGAS Pro

VEGAS Pro si estende con script **C#/.NET** (niente HTML, niente Python).
Questo script apre una finestra Windows Forms con lo stesso flusso degli
altri plugin: login → genera → polling → download → import nel
**Project Media**, con opzione per inserire la clip **direttamente in
timeline alla posizione del cursore**.

---

## ⚙️ Installazione

### 1. Configura le chiavi
Apri `FrameAI_Studio.cs` e compila in cima alla classe `FrameAIForm`:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

### 2. Copia ENTRAMBI i file nella cartella Script Menu
Copia `FrameAI_Studio.cs` **e** `FrameAI_Studio.cs.config` in:

```
C:\Users\<utente>\Documents\Vegas Script Menu\
```

(se la cartella non esiste, creala — in alternativa la cartella
`Script Menu` dentro la directory di installazione di VEGAS)

Il file `.cs.config` è necessario: aggiunge il riferimento a
`System.Web.Extensions.dll` per il parsing JSON.

### 3. Lancia
In VEGAS: `Tools → Scripting → Rescan Script Menu Folder`,
poi `Tools → Scripting → FrameAI_Studio`.

---

## 📝 Note tecniche

- Compatibile con **VEGAS Pro 14+** (namespace `ScriptPortal.Vegas`).
  Per Sony Vegas ≤13 cambia la riga `using ScriptPortal.Vegas;`
  in `using Sony.Vegas;`
- Forza TLS 1.2 (necessario per HTTPS su .NET Framework)
- La generazione gira in un `BackgroundWorker`: la finestra resta reattiva
- Video scaricati in `Documenti\FrameAI-Videos\`
- L'inserimento in timeline usa l'API eventi di VEGAS
  (`VideoTrack → VideoEvent → AddTake`); se la tua versione ha firme
  leggermente diverse su `AddMedia`, segnalamelo che lo adatto

## ⚠️ Limitazione rispetto agli altri plugin

VEGAS esegue gli script in modo "modale": la finestra di FrameAI resta
aperta sopra VEGAS finché non la chiudi. Per un pannello dockabile servirebbe
una **Vegas Extension** (DLL compilata con `ICustomCommandModule`) — è
l'evoluzione naturale di questo script, fattibile in un secondo momento.
