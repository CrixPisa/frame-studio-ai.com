# ============================================================
# FrameAI Studio — Addon per Blender 3.x / 4.x
# Pannello nel Video Sequencer e nella Vista 3D (sidebar N):
# login -> genera video/immagine -> polling -> import in timeline
# Solo stdlib (urllib) cosi' non servono pacchetti extra.
# Stessi contratti API dei plugin Nuke/Resolve (useGeneration.ts).
# ============================================================

bl_info = {
    "name": "FrameAI Studio",
    "author": "FrameAI",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "Video Sequencer / 3D Viewport > Sidebar (N) > FrameAI",
    "description": "Genera video e immagini AI con FrameAI e importali nella timeline",
    "doc_url": "https://frame-studio-ai.com/plugin",
    "category": "Sequencer",
}

import json
import math
import os
import threading
import urllib.request
import urllib.error
from datetime import datetime

import bpy

# ── CONFIGURAZIONE ──────────────────────────────────────────
# ⚠️ Stessi valori pubblici degli altri plugin (dal .env di FrameAI)
SUPABASE_URL = "https://vyngrcrudvxoxbehwrqv.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0"

POLL_INTERVAL_S = 6.0
MAX_POLLS = 200
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "FrameAI-Videos")

# Modelli video — allineati a src/lib/credits.ts v12 (2026-07-10)
VIDEO_MODELS = [
    ("ltx-2",         "LTX-2 (Free)",          "Open source, veloce, con audio"),
    ("seedance-1.5",  "Seedance 1.5 (Starter)", "Economico, audio incluso"),
    ("seedance-mini", "Seedance Mini (Starter)", "Seedance 2.0 economico, con audio"),
    ("seedance-fast", "Seedance Fast (Starter)", "Seedance veloce, con audio"),
    ("wan-2.6",       "Wan 2.6 (Starter)",      "Video fluidi fino a 10s, senza audio"),
    ("kling-2.6",     "Kling 2.6 Pro (Creator)", "Controllo voce nel prompt"),
    ("kling-3.0",     "Kling 3.0 (Creator)",    "Qualita' cinematografica, audio"),
    ("kling-turbo",   "Kling Turbo (Creator)",  "Kling veloce ed economico"),
    ("seedance-2.0",  "Seedance 2.0 (Creator)", "Top ByteDance, fisica realistica"),
    ("omni-flash",    "Omni Flash (Creator)",   "Google, coerenza superiore"),
    ("kling-o3",      "Kling O3 (Business)",    "Keyframe control, 15s"),
    ("veo-3.1-lite",  "Veo 3.1 Lite (Business)", "Google a meta' prezzo"),
    ("veo-3.1",       "Veo 3.1 (Agency)",       "Google DeepMind, lip-sync perfetto"),
]
RATIOS = [("16:9", "16:9", ""), ("9:16", "9:16", ""), ("1:1", "1:1", ""),
          ("21:9", "21:9", ""), ("4:3", "4:3", "")]
DURATIONS = [("5", "5s", ""), ("8", "8s", ""), ("10", "10s", ""), ("15", "15s", "")]
RESOLUTIONS = [("720p", "720p", ""), ("1080p", "1080p", "")]

IMAGE_MODELS = [
    ("flux-schnell",    "Flux Schnell (Free)",      "Veloce ed economico"),
    ("flux-dev",        "Flux Dev (Starter)",       "Fotorealismo"),
    ("flux2",           "Flux 2.0 Pro (Starter)",   "Alta qualita'"),
    ("flux2-pro",       "Flux 2 Pro (Starter)",     "Studio grade"),
    ("gpt-image-2",     "GPT Image 2 (Starter)",    "Testo e loghi perfetti"),
    ("nano-banana-2",   "Nano Banana 2 (Creator)",  "Personaggi coerenti"),
    ("nano-banana-pro", "Nano Banana Pro (Business)", "Google, top quality"),
    ("seedream",        "Seedream 5.0 (Business)",  "Anime e illustrazione"),
]
IMAGE_RATIOS = [("1:1", "1:1", ""), ("16:9", "16:9", ""), ("9:16", "9:16", ""), ("4:3", "4:3", "")]

# Replica di src/lib/credits.ts (v12)
_MAX_COST_PER_CREDIT = 0.063
_COST_PER_SEC = {
    "ltx-2": 0.004, "wan-2.6": 0.100, "seedance-2.0": 0.303,
    "seedance-mini": 0.072, "seedance-fast": 0.242, "seedance-1.5": 0.052,
    "kling-3.0": 0.140, "kling-2.6": 0.140, "kling-turbo": 0.112,
    "kling-o3": 0.112, "veo-3.1": 0.200, "veo-3.1-lite": 0.080,
    "omni-flash": 0.125,
}
_RES_MULT = {"720p": 1.0, "1080p": 1.5}
_IMG_COST = {
    "flux-schnell": 1, "flux-dev": 1, "flux2": 1, "flux2-pro": 1,
    "gpt-image-2": 1, "nano-banana-2": 2, "nano-banana-pro": 3, "seedream": 1,
}


def credit_cost(model, duration, resolution="720p"):
    per_sec = _COST_PER_SEC.get(model, 0.10)
    usd = per_sec * duration * _RES_MULT.get(resolution, 1.0)
    return max(1, math.ceil(usd / _MAX_COST_PER_CREDIT))


def credit_cost_image(model):
    return _IMG_COST.get(model, 1)


# ── HTTP helper (stdlib) ────────────────────────────────────
def _request(url, payload=None, headers=None, method=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method or ("POST" if data else "GET"))
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=60) as res:
            return json.loads(res.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {}
        msg = body.get("error") or body.get("error_description") or body.get("msg") or str(e)
        raise RuntimeError(msg)


class FrameAIClient(object):
    """Client API — stessi contratti di useGeneration.ts / plugin Nuke."""

    def __init__(self):
        self.session = None

    def login(self, email, password):
        data = _request(
            SUPABASE_URL + "/auth/v1/token?grant_type=password",
            {"email": email, "password": password},
            {"apikey": SUPABASE_ANON_KEY},
        )
        self.session = {
            "access_token": data["access_token"],
            "refresh_token": data["refresh_token"],
            "user_id": data.get("user", {}).get("id"),
            "email": data.get("user", {}).get("email", email),
        }
        return self.session

    def _fn_headers(self, token):
        return {"Authorization": "Bearer " + token, "apikey": SUPABASE_ANON_KEY}

    def profile(self):
        rows = _request(
            SUPABASE_URL + "/rest/v1/profiles?id=eq.%s&select=credits,plan" % self.session["user_id"],
            headers=self._fn_headers(self.session["access_token"]),
        )
        if not rows:
            raise RuntimeError("Impossibile leggere il profilo")
        return rows[0]

    def generate_video(self, payload):
        data = _request(
            SUPABASE_URL + "/functions/v1/generate-video",
            payload,
            self._fn_headers(self.session["access_token"]),
        )
        if not data.get("id") or not data.get("modelId"):
            raise RuntimeError(data.get("error", "Risposta non valida dal server"))
        return data

    def poll_video(self, job_id, model_id):
        return _request(
            SUPABASE_URL + "/functions/v1/poll-video",
            {"requestId": job_id, "falEndpoint": model_id},
            self._fn_headers(SUPABASE_ANON_KEY),
        )

    def generate_image(self, payload):
        data = _request(
            SUPABASE_URL + "/functions/v1/generate-image",
            payload,
            self._fn_headers(self.session["access_token"]),
        )
        if data.get("error"):
            raise RuntimeError(data["error"])
        out = data.get("output") or []
        url = out[0] if out else (data.get("imageUrl") or data.get("url"))
        if not url:
            raise RuntimeError("Nessuna immagine restituita")
        return url

    def consume_credits(self, amount):
        try:
            _request(
                SUPABASE_URL + "/functions/v1/consume-credits",
                {"userId": self.session["user_id"], "amount": amount},
                self._fn_headers(self.session["access_token"]),
            )
        except Exception:
            pass

    def save_generation(self, file_url, meta):
        try:
            payload = {"userId": self.session["user_id"], "fileUrl": file_url}
            payload.update(meta)
            _request(
                SUPABASE_URL + "/functions/v1/save-generation",
                payload,
                self._fn_headers(self.session["access_token"]),
            )
        except Exception:
            pass


# ── Stato condiviso worker <-> UI ───────────────────────────
# Blender non permette di toccare la UI da thread secondari:
# il worker scrive qui, un bpy.app.timers legge e aggiorna.
_client = FrameAIClient()
_state = {
    "running": False, "progress": 0, "label": "",
    "error": "", "result_path": "", "result_kind": "",
    "credits": "", "plan": "",
}
_state_lock = threading.Lock()


def _set_state(**kw):
    with _state_lock:
        _state.update(kw)


def _get_state():
    with _state_lock:
        return dict(_state)


def _redraw_ui():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in ("SEQUENCE_EDITOR", "VIEW_3D"):
                area.tag_redraw()


def _refresh_credits_sync():
    try:
        p = _client.profile()
        _set_state(credits=str(p.get("credits", "")), plan=str(p.get("plan", "")))
    except Exception:
        pass


# ── Worker: video ───────────────────────────────────────────
def _video_worker(payload, credits_used):
    try:
        _set_state(progress=15, label="Avvio generazione...")
        job = _client.generate_video(payload)

        _set_state(progress=30, label="Rendering con %s..." % payload["model"])
        url = None
        polls = 0
        while polls < MAX_POLLS:
            polls += 1
            result = _client.poll_video(job["id"], job["modelId"])
            url = result.get("outputUrl") or (result.get("output") or [None])[0]

            prog = result.get("progress") or 0
            if not result.get("done") and prog > 0:
                _set_state(progress=int(min(95, 30 + prog * 0.65)),
                           label="Rendering... %d%%" % int(prog))
            else:
                _set_state(progress=int(min(95, 30 + (polls / 100.0) * 65)),
                           label="Rendering in corso...")

            done = result.get("done") or result.get("status") in ("success", "COMPLETED")
            if done and url:
                break
            if result.get("status") == "error":
                raise RuntimeError(result.get("error", "Rendering fallito"))

            threading.Event().wait(POLL_INTERVAL_S)

        if not url:
            raise RuntimeError("Timeout — riprova con durata minore.")

        _client.consume_credits(credits_used)
        _client.save_generation(url, {
            "type": "video",
            "prompt": payload["prompt"],
            "model": payload["model"],
            "aspectRatio": payload["aspectRatio"],
            "creditsUsed": credits_used,
        })

        _set_state(progress=97, label="Download del video...")
        if not os.path.isdir(DOWNLOAD_DIR):
            os.makedirs(DOWNLOAD_DIR)
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        file_path = os.path.join(DOWNLOAD_DIR, "frameai_%s.mp4" % stamp)
        urllib.request.urlretrieve(url, file_path)

        _refresh_credits_sync()
        _set_state(running=False, progress=100, label="✅ Video pronto",
                   result_path=file_path, result_kind="video")
    except Exception as e:
        _set_state(running=False, progress=0, label="", error=str(e))


# ── Worker: immagine ────────────────────────────────────────
def _image_worker(payload, credits_used):
    try:
        _set_state(progress=25, label="Generazione immagine...")
        url = _client.generate_image(payload)
        _client.consume_credits(credits_used)
        _client.save_generation(url, {
            "type": "image",
            "prompt": payload.get("prompt", ""),
            "model": payload.get("model", ""),
            "creditsUsed": credits_used,
        })
        _set_state(progress=90, label="Download...")
        if not os.path.isdir(DOWNLOAD_DIR):
            os.makedirs(DOWNLOAD_DIR)
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        file_path = os.path.join(DOWNLOAD_DIR, "frameai_img_%s.jpg" % stamp)
        urllib.request.urlretrieve(url, file_path)

        _refresh_credits_sync()
        _set_state(running=False, progress=100, label="✅ Immagine pronta",
                   result_path=file_path, result_kind="image")
    except Exception as e:
        _set_state(running=False, progress=0, label="", error=str(e))


# ── Import del risultato nella scena (main thread) ──────────
def _next_free_channel(sequences):
    ch = 1
    for s in sequences:
        ch = max(ch, s.channel + 1)
    return ch


def _import_result(path, kind):
    scene = bpy.context.scene
    if not scene.sequence_editor:
        scene.sequence_editor_create()
    seqs = scene.sequence_editor.sequences
    name = os.path.splitext(os.path.basename(path))[0]
    start = scene.frame_current
    ch = _next_free_channel(seqs)
    if kind == "video":
        strip = seqs.new_movie(name=name, filepath=path, channel=ch, frame_start=start)
        # Traccia audio del clip (se il modello genera audio)
        try:
            seqs.new_sound(name=name + "_audio", filepath=path,
                           channel=ch + 1, frame_start=start)
        except Exception:
            pass
        # Adatta il range della scena al clip se piu' lungo
        try:
            if strip.frame_final_end > scene.frame_end:
                scene.frame_end = strip.frame_final_end
        except Exception:
            pass
    else:
        seqs.new_image(name=name, filepath=path, channel=ch, frame_start=start)
        # Rendi disponibile anche nell'Image Editor / come texture
        try:
            bpy.data.images.load(path, check_existing=True)
        except Exception:
            pass


# ── Timer: sincronizza stato worker -> UI ───────────────────
def _ui_timer():
    st = _get_state()
    _redraw_ui()
    if st["result_path"]:
        try:
            _import_result(st["result_path"], st["result_kind"])
        except Exception as e:
            _set_state(error="Import fallito: %s (file in %s)" % (e, st["result_path"]))
        _set_state(result_path="", result_kind="")
    if not st["running"] and not st["result_path"]:
        _redraw_ui()
        return None  # ferma il timer
    return 0.5


def _start_timer():
    if not bpy.app.timers.is_registered(_ui_timer):
        bpy.app.timers.register(_ui_timer, first_interval=0.5)


# ── Proprieta' UI ───────────────────────────────────────────
class FrameAIProps(bpy.types.PropertyGroup):
    email: bpy.props.StringProperty(name="Email", description="Email account FrameAI")
    password: bpy.props.StringProperty(name="Password", subtype="PASSWORD",
                                       description="Password FrameAI (non salvata nel .blend)")
    logged_in: bpy.props.BoolProperty(default=False)

    mode: bpy.props.EnumProperty(
        name="Modalita'",
        items=[("VIDEO", "🎬 Video", ""), ("IMAGE", "🖼 Immagine", "")],
        default="VIDEO",
    )

    prompt: bpy.props.StringProperty(
        name="Prompt", description="Descrivi la scena (in italiano, lo ottimizza il backend)")
    model: bpy.props.EnumProperty(name="Modello", items=[(v, l, d) for v, l, d in VIDEO_MODELS],
                                  default="wan-2.6")
    ratio: bpy.props.EnumProperty(name="Formato", items=RATIOS, default="16:9")
    duration: bpy.props.EnumProperty(name="Durata", items=DURATIONS, default="5")
    resolution: bpy.props.EnumProperty(name="Risoluzione", items=RESOLUTIONS, default="720p")

    img_prompt: bpy.props.StringProperty(
        name="Prompt", description="Descrivi l'immagine (in italiano)")
    img_model: bpy.props.EnumProperty(name="Modello", items=[(v, l, d) for v, l, d in IMAGE_MODELS],
                                      default="flux-dev")
    img_ratio: bpy.props.EnumProperty(name="Formato", items=IMAGE_RATIOS, default="16:9")


# ── Operatori ───────────────────────────────────────────────
class FRAMEAI_OT_login(bpy.types.Operator):
    bl_idname = "frameai.login"
    bl_label = "Accedi a FrameAI"
    bl_description = "Effettua il login con il tuo account FrameAI"

    def execute(self, context):
        props = context.window_manager.frameai
        _set_state(error="")
        try:
            _client.login(props.email.strip(), props.password)
            _refresh_credits_sync()
            props.logged_in = True
            props.password = ""  # non tenerla in memoria oltre il login
            self.report({"INFO"}, "Login effettuato")
        except Exception as e:
            _set_state(error=str(e))
            self.report({"ERROR"}, str(e))
        return {"FINISHED"}


class FRAMEAI_OT_logout(bpy.types.Operator):
    bl_idname = "frameai.logout"
    bl_label = "Esci"
    bl_description = "Disconnetti l'account FrameAI"

    def execute(self, context):
        _client.session = None
        context.window_manager.frameai.logged_in = False
        _set_state(credits="", plan="", error="")
        return {"FINISHED"}


class FRAMEAI_OT_generate_video(bpy.types.Operator):
    bl_idname = "frameai.generate_video"
    bl_label = "Genera video"
    bl_description = "Genera un video AI e importalo nella timeline"

    def execute(self, context):
        props = context.window_manager.frameai
        prompt = props.prompt.strip()
        if not prompt:
            self.report({"ERROR"}, "Scrivi un prompt prima di generare.")
            return {"CANCELLED"}
        if _get_state()["running"]:
            self.report({"WARNING"}, "Generazione gia' in corso.")
            return {"CANCELLED"}

        duration = int(props.duration)
        credits_used = credit_cost(props.model, duration, props.resolution)
        try:
            profile = _client.profile()
            if profile["credits"] < credits_used:
                msg = "Crediti insufficienti — hai %scr, servono %dcr." % (profile["credits"], credits_used)
                _set_state(error=msg)
                self.report({"ERROR"}, msg)
                return {"CANCELLED"}
        except Exception as e:
            _set_state(error=str(e))
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}

        payload = {
            "prompt": prompt,
            "model": props.model,
            "aspectRatio": props.ratio,
            "duration": duration,
            "resolution": props.resolution,
        }
        _set_state(running=True, progress=5, label="Avvio...", error="",
                   result_path="", result_kind="")
        threading.Thread(target=_video_worker, args=(payload, credits_used), daemon=True).start()
        _start_timer()
        return {"FINISHED"}


class FRAMEAI_OT_generate_image(bpy.types.Operator):
    bl_idname = "frameai.generate_image"
    bl_label = "Genera immagine"
    bl_description = "Genera un'immagine AI e importala nella timeline"

    def execute(self, context):
        props = context.window_manager.frameai
        prompt = props.img_prompt.strip()
        if not prompt:
            self.report({"ERROR"}, "Scrivi un prompt prima di generare.")
            return {"CANCELLED"}
        if _get_state()["running"]:
            self.report({"WARNING"}, "Generazione gia' in corso.")
            return {"CANCELLED"}

        credits_used = credit_cost_image(props.img_model)
        try:
            profile = _client.profile()
            if profile["credits"] < credits_used:
                msg = "Crediti insufficienti — hai %scr, servono %dcr." % (profile["credits"], credits_used)
                _set_state(error=msg)
                self.report({"ERROR"}, msg)
                return {"CANCELLED"}
        except Exception as e:
            _set_state(error=str(e))
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}

        payload = {
            "prompt": prompt,
            "model": props.img_model,
            "ratio": props.img_ratio,
            "resolution": "1024",
        }
        _set_state(running=True, progress=5, label="Avvio...", error="",
                   result_path="", result_kind="")
        threading.Thread(target=_image_worker, args=(payload, credits_used), daemon=True).start()
        _start_timer()
        return {"FINISHED"}


# ── Pannello ────────────────────────────────────────────────
def _draw_panel(layout, context):
    props = context.window_manager.frameai
    st = _get_state()

    # Header crediti
    if props.logged_in and st["credits"]:
        row = layout.row(align=True)
        row.label(text="⚡ %scr · %s" % (st["credits"], st["plan"]), icon="FUND")
        row.operator("frameai.logout", text="", icon="QUIT")

    if not props.logged_in:
        col = layout.column(align=True)
        col.prop(props, "email")
        col.prop(props, "password")
        col.operator("frameai.login", icon="KEY_HLT")
        if st["error"]:
            box = layout.box()
            box.alert = True
            box.label(text=st["error"][:80], icon="ERROR")
        return

    layout.row().prop(props, "mode", expand=True)

    if props.mode == "VIDEO":
        col = layout.column(align=True)
        col.prop(props, "prompt", text="")
        col.prop(props, "model", text="")
        row = col.row(align=True)
        row.prop(props, "ratio", text="")
        row.prop(props, "duration", text="")
        row.prop(props, "resolution", text="")
        cost = credit_cost(props.model, int(props.duration), props.resolution)
        layout.label(text="Costo: ⚡ %dcr" % cost)
        row = layout.row()
        row.enabled = not st["running"]
        row.operator("frameai.generate_video", icon="RENDER_ANIMATION")
    else:
        col = layout.column(align=True)
        col.prop(props, "img_prompt", text="")
        col.prop(props, "img_model", text="")
        col.prop(props, "img_ratio", text="")
        cost = credit_cost_image(props.img_model)
        layout.label(text="Costo: ⚡ %dcr" % cost)
        row = layout.row()
        row.enabled = not st["running"]
        row.operator("frameai.generate_image", icon="IMAGE_DATA")

    # Progresso / stato
    if st["running"] or st["label"]:
        box = layout.box()
        box.label(text=st["label"] or "In corso...", icon="TIME" if st["running"] else "CHECKMARK")
        if st["running"]:
            box.label(text="▮" * int(st["progress"] / 10) + "▯" * (10 - int(st["progress"] / 10))
                      + "  %d%%" % st["progress"])
    if st["error"]:
        box = layout.box()
        box.alert = True
        box.label(text=st["error"][:80], icon="ERROR")


class FRAMEAI_PT_sequencer(bpy.types.Panel):
    bl_label = "FrameAI Studio"
    bl_space_type = "SEQUENCE_EDITOR"
    bl_region_type = "UI"
    bl_category = "FrameAI"

    def draw(self, context):
        _draw_panel(self.layout, context)


class FRAMEAI_PT_view3d(bpy.types.Panel):
    bl_label = "FrameAI Studio"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "FrameAI"

    def draw(self, context):
        _draw_panel(self.layout, context)


# ── Registrazione ───────────────────────────────────────────
_classes = (
    FrameAIProps,
    FRAMEAI_OT_login,
    FRAMEAI_OT_logout,
    FRAMEAI_OT_generate_video,
    FRAMEAI_OT_generate_image,
    FRAMEAI_PT_sequencer,
    FRAMEAI_PT_view3d,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.frameai = bpy.props.PointerProperty(type=FrameAIProps)


def unregister():
    if bpy.app.timers.is_registered(_ui_timer):
        bpy.app.timers.unregister(_ui_timer)
    del bpy.types.WindowManager.frameai
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
