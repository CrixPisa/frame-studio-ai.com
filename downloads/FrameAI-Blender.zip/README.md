# FrameAI Studio — Addon per Blender

Genera video e immagini AI con FrameAI direttamente dentro Blender e importali
automaticamente nella timeline del Video Sequencer.

Compatibile con **Blender 3.0+** (testato con la serie 3.x e 4.x). Nessuna
dipendenza esterna: usa solo la libreria standard di Python inclusa in Blender.

## Installazione

1. Scarica `frameai_blender.py`
2. In Blender: **Edit → Preferences → Add-ons → Install...**
3. Seleziona il file `frameai_blender.py`
4. Attiva la spunta su **FrameAI Studio** nella lista addon

## Dove si trova

Il pannello appare nella **sidebar (tasto N)** in due editor:

- **Video Sequencer** → tab "FrameAI" (uso principale: montaggio)
- **3D Viewport** → tab "FrameAI" (comodo per reference e texture)

## Uso

1. Accedi con email e password del tuo account [FrameAI](https://frame-studio-ai.com)
   (la password non viene salvata nel file .blend)
2. Scegli **Video** o **Immagine**
3. Scrivi il prompt (in italiano — lo ottimizza il backend), scegli modello,
   formato, durata e risoluzione. Il costo in crediti è mostrato prima di generare.
4. Premi **Genera**: al termine il risultato viene scaricato in
   `~/FrameAI-Videos/` e importato automaticamente nel Video Sequencer
   come strip (video + traccia audio se il modello genera audio) alla
   posizione corrente del playhead.

Le immagini generate vengono anche caricate in `bpy.data.images`, quindi
disponibili subito nell'Image Editor e come texture.

## Modelli disponibili

Gli stessi della web app, in base al tuo piano: LTX-2 (Free), Seedance
1.5/Mini/Fast, Wan 2.6 (Starter), Kling 2.6 Pro/3.0/Turbo, Seedance 2.0,
Omni Flash (Creator), Kling O3, Veo 3.1 Lite (Business), Veo 3.1 (Agency).

## Note

- La generazione avviene in un thread separato: Blender resta usabile durante
  il rendering (1-5 minuti a seconda del modello).
- I crediti vengono verificati prima della generazione e scalati solo a
  risultato consegnato.
- Se il file generato non viene importato (es. sequencer non inizializzato),
  lo trovi comunque in `~/FrameAI-Videos/`.
