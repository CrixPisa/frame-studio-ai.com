// ============================================================
// FrameAI — hostscript.jsx (ExtendScript, gira DENTRO After Effects)
// Importa video, immagini e risultati tool nel progetto AE
// ============================================================

// Import generico (video, immagine, qualsiasi footage)
function importFrameAIFile(path) {
  try {
    var f = new File(path);
    if (!f.exists) return 'ERROR: file non trovato: ' + path;

    var io = new ImportOptions(f);
    if (!io.canImportAs(ImportAsType.FOOTAGE)) {
      return 'ERROR: formato non importabile';
    }
    io.importAs = ImportAsType.FOOTAGE;

    var item = app.project.importFile(io);

    // Mettilo nella cartella "FrameAI" nel project panel
    var folder = null;
    for (var i = 1; i <= app.project.numItems; i++) {
      var it = app.project.item(i);
      if (it instanceof FolderItem && it.name === 'FrameAI') { folder = it; break; }
    }
    if (!folder) folder = app.project.items.addFolder('FrameAI');
    item.parentFolder = folder;

    return 'OK';
  } catch (e) {
    return 'ERROR: ' + e.toString();
  }
}

// Alias esplicito per i video (retrocompatibilità)
function importFrameAIVideo(path) {
  return importFrameAIFile(path);
}

// Crea una comp dal video/footage appena importato e la apre (opzionale)
function importAndCreateComp(path) {
  try {
    var result = importFrameAIFile(path);
    if (result !== 'OK') return result;

    var f = new File(path);
    var item = null;
    for (var i = 1; i <= app.project.numItems; i++) {
      var it = app.project.item(i);
      if (it instanceof FootageItem && it.file && it.file.fsName === f.fsName) {
        item = it; break;
      }
    }
    if (!item) return 'ERROR: item non trovato dopo import';

    var comp = app.project.items.addComp(
      item.name.replace(/\.[^\.]+$/, ''),
      item.width  || 1920,
      item.height || 1080,
      item.pixelAspect || 1,
      item.duration || 5,
      item.frameRate || 30
    );
    comp.layers.add(item);
    comp.openInViewer();
    return 'OK';
  } catch (e) {
    return 'ERROR: ' + e.toString();
  }
}
