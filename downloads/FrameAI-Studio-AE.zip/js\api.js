// ============================================================
// FrameAI Plugin AE — API client (versione CEP, globali)
// Video + Immagine + Tools
// ============================================================

;(function () {
  const CFG = window.FRAMEAI_CONFIG
  const URL_BASE = CFG.SUPABASE_URL
  const ANON_KEY = CFG.SUPABASE_ANON_KEY
  const SESSION_KEY = 'frameai-plugin-auth'

  // Node.js dentro CEP
  const nodeRequire = (window.cep_node && window.cep_node.require) || window.require
  const fs   = nodeRequire('fs')
  const path = nodeRequire('path')
  const os   = nodeRequire('os')

  function loadSession() {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)) } catch (e) { return null }
  }
  function saveSession(s) {
    if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s))
    else localStorage.removeItem(SESSION_KEY)
  }

  async function login(email, password) {
    const res = await fetch(URL_BASE + '/auth/v1/token?grant_type=password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': ANON_KEY },
      body: JSON.stringify({ email: email, password: password }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error_description || data.msg || 'Login fallito')
    const session = {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresAt: Date.now() + (data.expires_in || 3600) * 1000,
      userId: data.user && data.user.id,
      email: (data.user && data.user.email) || email,
    }
    saveSession(session)
    return session
  }

  async function refreshSession(session) {
    const res = await fetch(URL_BASE + '/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'apikey': ANON_KEY },
      body: JSON.stringify({ refresh_token: session.refreshToken }),
    })
    const data = await res.json()
    if (!res.ok) { saveSession(null); throw new Error('Sessione scaduta, rifai il login') }
    const next = {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresAt: Date.now() + (data.expires_in || 3600) * 1000,
      userId: (data.user && data.user.id) || session.userId,
      email: (data.user && data.user.email) || session.email,
    }
    saveSession(next)
    return next
  }

  async function getSession() {
    let s = loadSession()
    if (!s) return null
    if (Date.now() > s.expiresAt - 60000) {
      try { s = await refreshSession(s) } catch (e) { return null }
    }
    return s
  }

  function logout() { saveSession(null) }

  async function getProfile(session) {
    const res = await fetch(
      URL_BASE + '/rest/v1/profiles?id=eq.' + session.userId + '&select=credits,plan,email',
      { headers: { 'apikey': ANON_KEY, 'Authorization': 'Bearer ' + session.accessToken } }
    )
    const rows = await res.json()
    if (!res.ok || !Array.isArray(rows) || rows.length === 0) throw new Error('Impossibile leggere il profilo')
    return rows[0]
  }

  function fnHeaders(token) {
    return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token, 'apikey': ANON_KEY }
  }

  async function generateVideo(session, payload) {
    const res = await fetch(URL_BASE + '/functions/v1/generate-video', {
      method: 'POST', headers: fnHeaders(session.accessToken), body: JSON.stringify(payload),
    })
    const text = await res.text()
    let data
    try { data = JSON.parse(text) } catch (e) { data = { error: text } }
    if (!res.ok || data.error) throw new Error(data.error || ('Errore ' + res.status))
    if (!data.id) throw new Error('Nessun job ID ricevuto. Riprova.')
    if (!data.modelId) throw new Error('Modello non riconosciuto. Riprova.')
    return data
  }

  async function pollVideo(jobId, modelId) {
    const res = await fetch(URL_BASE + '/functions/v1/poll-video', {
      method: 'POST', headers: fnHeaders(ANON_KEY),
      body: JSON.stringify({ requestId: jobId, falEndpoint: modelId }),
    })
    return res.json()
  }

  // POST generate-image → { output:[url] } oppure { imageUrl }
  async function generateImage(session, payload) {
    const res = await fetch(URL_BASE + '/functions/v1/generate-image', {
      method: 'POST', headers: fnHeaders(session.accessToken), body: JSON.stringify(payload),
    })
    const text = await res.text()
    let data
    try { data = JSON.parse(text) } catch (e) { data = { error: text } }
    if (!res.ok || data.error) throw new Error(data.error || ('Errore ' + res.status))
    const out = data.output || []
    const url = out[0] || data.imageUrl || data.url
    if (!url) throw new Error('Nessuna immagine restituita dal server')
    return url
  }

  // Upload multipart con Node fs (CEP ha accesso filesystem)
  async function uploadTemp(session, filePath) {
    const FormData = nodeRequire('form-data')
    const form = new FormData()
    form.append('file', fs.createReadStream(filePath), path.basename(filePath))
    const headers = Object.assign(form.getHeaders(), {
      'Authorization': 'Bearer ' + session.accessToken,
      'apikey': ANON_KEY,
    })
    const res = await fetch(URL_BASE + '/functions/v1/upload-temp', {
      method: 'POST', headers: headers, body: form,
    })
    const data = await res.json()
    if (!res.ok || !data.url) throw new Error(data.error || 'Upload del file fallito')
    return data.url
  }

  async function toolsProcess(session, payload) {
    const res = await fetch(URL_BASE + '/functions/v1/tools-process', {
      method: 'POST', headers: fnHeaders(session.accessToken), body: JSON.stringify(payload),
    })
    const data = await res.json()
    if (!res.ok || data.error) throw new Error(data.error || ('Errore ' + res.status))
    return data
  }

  async function toolJobStatus(session, jobId) {
    const res = await fetch(
      URL_BASE + '/rest/v1/tool_jobs?id=eq.' + jobId + '&select=status,output_url,error_msg,fal_progress',
      { headers: { 'apikey': ANON_KEY, 'Authorization': 'Bearer ' + session.accessToken } }
    )
    const rows = await res.json()
    return rows && rows[0]
  }

  function consumeCredits(session, amount) {
    return fetch(URL_BASE + '/functions/v1/consume-credits', {
      method: 'POST', headers: fnHeaders(session.accessToken),
      body: JSON.stringify({ userId: session.userId, amount: amount }),
    }).catch(function () {})
  }

  function saveGeneration(session, fileUrl, meta) {
    return fetch(URL_BASE + '/functions/v1/save-generation', {
      method: 'POST', headers: fnHeaders(session.accessToken),
      body: JSON.stringify(Object.assign({ userId: session.userId, fileUrl: fileUrl }, meta)),
    }).catch(function () {})
  }

  // ── Download con Node fs ──────────────────────────────────
  async function downloadFile(url, prefix, ext) {
    const res = await fetch(url)
    if (!res.ok) throw new Error('Download fallito')
    const buffer = Buffer.from(await res.arrayBuffer())
    const dir = path.join(os.homedir(), 'Documents', 'FrameAI-Videos')
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    const filePath = path.join(dir, prefix + '_' + stamp + '.' + ext)
    fs.writeFileSync(filePath, buffer)
    return filePath
  }

  // ── Costi ──────────────────────────────────────────────────
  const MAX_API_COST_PER_CREDIT_USD = 0.063
  const FAL_VIDEO_COST_PER_SEC = {
    'ltx-2': 0.004, 'wan-2.6': 0.100, 'seedance-2.0': 0.303,
    'seedance-fast': 0.242, 'seedance-1.5': 0.052, 'seedance-2-i2v': 0.242,
    'kling-3.0': 0.140, 'sora-2': 0.150, 'veo-3.1': 0.200,
  }
  const RES_MULT = { '720p': 1.0, '1080p': 1.5 }
  const IMG_COST = {
    'flux-schnell': 1, 'flux-dev': 1, 'flux2': 2,
    'nano-banana-2': 2, 'nano-banana-pro': 3, 'seedream': 1,
  }

  function getVideoCreditCost(model, durationSeconds, resolution) {
    const costPerSec = FAL_VIDEO_COST_PER_SEC[model] || 0.10
    const apiCostUSD = costPerSec * durationSeconds * (RES_MULT[resolution || '720p'] || 1.0)
    return Math.max(1, Math.ceil(apiCostUSD / MAX_API_COST_PER_CREDIT_USD))
  }

  function getImageCreditCost(model) {
    return IMG_COST[model] || 1
  }

  window.FrameAIAPI = {
    login: login, logout: logout, getSession: getSession,
    getProfile: getProfile,
    generateVideo: generateVideo, pollVideo: pollVideo,
    generateImage: generateImage,
    uploadTemp: uploadTemp, toolsProcess: toolsProcess, toolJobStatus: toolJobStatus,
    consumeCredits: consumeCredits, saveGeneration: saveGeneration,
    getVideoCreditCost: getVideoCreditCost, getImageCreditCost: getImageCreditCost,
    downloadFile: downloadFile,
  }
})()
