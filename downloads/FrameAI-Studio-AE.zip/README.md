# FrameAI Studio — Plugin After Effects (CEP)

After Effects non supporta ancora UXP, quindi questa versione usa CEP:
pannello HTML/JS + ponte ExtendScript per importare i video nel progetto.
Stessa UI, stesse API e stessi crediti della versione Premiere.

---

## ⚙️ Setup sviluppo

### 1. Configura le chiavi
Apri `js/config.js` e inserisci `SUPABASE_URL` e `SUPABASE_ANON_KEY`
(stessi valori di `plugins/premiere-uxp/config.js`).

### 2. Abilita le estensioni non firmate (solo per lo sviluppo)
CEP carica estensioni non firmate solo in "PlayerDebugMode".
Su Windows, esegui in PowerShell (per CEP 11 e 12):

```powershell
New-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.11" -Name PlayerDebugMode -Value 1 -PropertyType String -Force
New-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.12" -Name PlayerDebugMode -Value 1 -PropertyType String -Force
```

Su macOS:
```bash
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

### 3. Installa l'estensione
Copia (o crea un link simbolico di) questa cartella in:

- **Windows:** `C:\Users\<utente>\AppData\Roaming\Adobe\CEP\extensions\frameai-ae`
- **macOS:** `~/Library/Application Support/Adobe/CEP/extensions/frameai-ae`

Esempio Windows (PowerShell, dalla cartella FrameAI):
```powershell
New-Item -ItemType Junction -Path "$env:APPDATA\Adobe\CEP\extensions\frameai-ae" -Target ".\plugins\aftereffects-cep"
```
(Il junction ti permette di modificare i file qui e vederli subito in AE.)

### 4. Apri After Effects
`Window → Extensions → FrameAI Studio`

Debug del pannello: con AE aperto vai su `http://localhost:8092` in Chrome
(porta definita nel file `.debug`).

---

## 🎬 Differenze rispetto alla versione Premiere

- Il download usa Node.js (fs) integrato in CEP → i video finiscono in
  `Documenti/FrameAI-Videos/`
- L'import passa per ExtendScript (`jsx/hostscript.jsx`):
  - `importFrameAIVideo(path)` → importa nel project panel, cartella "FrameAI"
  - `importAndCreateComp(path)` → importa E crea una comp già aperta nel viewer
    (checkbox "Crea una comp dal video" nel pannello)

## 📦 Distribuzione (.zxp)

Per distribuire agli utenti serve un pacchetto ZXP firmato:

1. Scarica **ZXPSignCmd** (Adobe, gratuito)
2. Crea un certificato self-signed:
   ```
   ZXPSignCmd -selfSignedCert IT Toscana FrameAI "FrameAI" password certificato.p12
   ```
3. Firma e pacchettizza:
   ```
   ZXPSignCmd -sign plugins\aftereffects-cep FrameAI-Studio-AE.zxp certificato.p12 password -tsa http://timestamp.digicert.com
   ```
4. Gli utenti installano il .zxp con un installer gratuito tipo
   **ZXP Installer** (aescripts.com) oppure pubblichi su Adobe Marketplace.

Metti il file in `public/downloads/FrameAI-Studio-AE.zxp` e aggiungi il
pulsante nella pagina /plugin del sito.

## 📁 Struttura

```
aftereffects-cep/
├── CSXS/manifest.xml   # Manifest CEP (host AEFT ≥ 17.0)
├── .debug              # Porta debug Chrome (8092)
├── index.html          # UI pannello
├── styles.css          # Tema dark FrameAI
├── js/config.js        # ⚠️ DA COMPILARE
├── js/api.js           # Client API (identico in logica a premiere-uxp)
├── js/main.js          # Logica pannello + download + evalScript
└── jsx/hostscript.jsx  # ExtendScript: import + creazione comp in AE
```
