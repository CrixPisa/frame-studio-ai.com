// ============================================================
// FrameAI Plugin AE — main.js
// Video + Immagine + Tools → Download (Node fs) → Import in AE
// ============================================================

;(function () {
  const CFG = window.FRAMEAI_CONFIG
  const api = window.FrameAIAPI

  const nodeRequire = (window.cep_node && window.cep_node.require) || window.require
  const path = nodeRequire('path')
  const os   = nodeRequire('os')

  function evalScript(script) {
    return new Promise(function (resolve) {
      window.__adobe_cep__.evalScript(script, resolve)
    })
  }

  const $ = function (id) { return document.getElementById(id) }
  const views = { config: $('view-config'), login: $('view-login'), generator: $('view-generator') }

  let currentSession = null
  let cancelledVideo = false
  let lastVideoPath = null, lastVideoUrl = null
  let lastImagePath = null, lastImageUrl = null
  let lastToolPath = null, lastToolUrl = null
  let toolFilePath = null

  // ── View ────────────────────────────────────────────────
  function showView(name) {
    Object.keys(views).forEach(function (k) {
      views[k].classList.toggle('hidden', k !== name)
    })
  }

  function setError(id, msg) {
    const el = $(id)
    if (!msg) { el.classList.add('hidden'); el.textContent = ''; return }
    el.textContent = msg
    el.classList.remove('hidden')
  }

  function setProgress(suffix, pct, label) {
    $('progress-wrap-' + suffix).classList.remove('hidden')
    $('progress-fill-' + suffix).style.width = Math.round(pct) + '%'
    if (label) $('progress-label-' + suffix).textContent = label
  }

  function hideProgress(suffix) {
    $('progress-wrap-' + suffix).classList.add('hidden')
  }

  async function refreshCredits() {
    try {
      const profile = await api.getProfile(currentSession)
      $('credits-badge').textContent = '⚡ ' + profile.credits + 'cr · ' + profile.plan
    } catch (e) { $('credits-badge').textContent = '⚡ —' }
  }

  // ── Tab ──────────────────────────────────────────────────
  function setTab(name) {
    ;['video', 'image', 'tools'].forEach(function (t) {
      $('tab-' + t).classList.toggle('active', t === name)
      $('page-' + t).classList.toggle('hidden', t !== name)
    })
  }
  $('tab-video').addEventListener('click', function () { setTab('video') })
  $('tab-image').addEventListener('click', function () { setTab('image') })
  $('tab-tools').addEventListener('click', function () { setTab('tools') })

  // ── Costi ────────────────────────────────────────────────
  function updateVideoCost() {
    const cost = api.getVideoCreditCost(
      $('gen-model').value,
      parseInt($('gen-duration').value, 10),
      $('gen-resolution').value
    )
    $('gen-cost').textContent = '⚡ ' + cost + 'cr'
  }
  ;['gen-model', 'gen-duration', 'gen-resolution'].forEach(function (id) {
    $(id).addEventListener('change', updateVideoCost)
  })

  function updateImageCost() {
    $('img-cost').textContent = '⚡ ' + api.getImageCreditCost($('img-model').value) + 'cr'
  }
  $('img-model').addEventListener('change', updateImageCost)

  // ── Tools UI ─────────────────────────────────────────────
  function updateToolsUI() {
    const parts = $('tools-tool').value.split('|')
    const cat = parts[1]
    const needsPrompt = parts[3] === 'true'
    $('tools-hint').textContent = 'Input: ' + (cat === 'video' ? 'video (mp4/mov)' : 'immagine (png/jpg/webp/exr)')
    $('tools-prompt-wrap').classList.toggle('hidden', !needsPrompt)
    toolFilePath = null
    $('tools-file-name').textContent = ''
  }
  $('tools-tool').addEventListener('change', updateToolsUI)

  // File picker per tools (usa input[type=file] nascosto — CEP non ha file picker nativo JS)
  $('btn-tools-file').addEventListener('click', function () {
    const parts = $('tools-tool').value.split('|')
    const cat = parts[1]
    const accept = cat === 'video' ? '.mp4,.mov,.webm,.avi' : '.png,.jpg,.jpeg,.webp,.exr,.tif,.tiff'
    const inp = document.createElement('input')
    inp.type = 'file'
    inp.accept = accept
    inp.onchange = function () {
      if (inp.files && inp.files[0]) {
        toolFilePath = inp.files[0].path  // CEP espone il path nativo
        $('tools-file-name').textContent = '✓ ' + inp.files[0].name
      }
    }
    inp.click()
  })

  // ── Import in AE via ExtendScript ───────────────────────
  async function importIntoAE(filePath, makeComp) {
    const escaped = filePath.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
    const fn = makeComp ? 'importAndCreateComp' : 'importFrameAIFile'
    const result = await evalScript(fn + '("' + escaped + '")')
    if (result !== 'OK') throw new Error(result || 'Import fallito — trascina il file manualmente')
    return true
  }

  // ════════════════════════════════════════════════════════
  // GENERA VIDEO
  // ════════════════════════════════════════════════════════
  async function generateVideo() {
    const prompt = $('gen-prompt').value.trim()
    if (!prompt) { setError('gen-error', 'Scrivi un prompt prima di generare.'); return }
    setError('gen-error', null)
    $('result-wrap-video').classList.add('hidden')
    cancelledVideo = false

    const model = $('gen-model').value
    const aspectRatio = $('gen-ratio').value
    const duration = parseInt($('gen-duration').value, 10)
    const resolution = $('gen-resolution').value
    const creditsUsed = api.getVideoCreditCost(model, duration, resolution)
    const btn = $('btn-generate')
    btn.disabled = true

    try {
      currentSession = await api.getSession()
      if (!currentSession) { showView('login'); return }
      const profile = await api.getProfile(currentSession)
      if (profile.credits < creditsUsed)
        throw new Error('Crediti insufficienti — hai ' + profile.credits + 'cr, servono ' + creditsUsed + 'cr.')

      setProgress('video', 15, 'Avvio generazione...')
      const job = await api.generateVideo(currentSession, {
        prompt: prompt, model: model, aspectRatio: aspectRatio,
        duration: duration, resolution: resolution,
      })
      setProgress('video', 30, 'Rendering con ' + model + '...')

      let polls = 0, url = null
      while (polls < CFG.MAX_POLLS) {
        if (cancelledVideo) { hideProgress('video'); btn.disabled = false; return }
        polls++
        const result = await api.pollVideo(job.id, job.modelId)
        url = result.outputUrl || (result.output && result.output[0]) || null
        if (!result.done && result.progress > 0)
          setProgress('video', Math.min(95, 30 + result.progress * 0.65), 'Rendering... ' + Math.round(result.progress) + '%')
        else
          setProgress('video', Math.min(95, 30 + (polls / 100) * 65), 'Rendering in corso...')
        if ((result.done || result.status === 'success' || result.status === 'COMPLETED') && url) break
        if (result.status === 'error') throw new Error(result.error || 'Rendering fallito')
        await new Promise(function (r) { setTimeout(r, CFG.POLL_INTERVAL_MS) })
      }
      if (!url) throw new Error('Timeout — la generazione ha impiegato troppo. Riprova con durata minore.')

      api.consumeCredits(currentSession, creditsUsed)
      api.saveGeneration(currentSession, url, { type: 'video', prompt: prompt, model: model, aspectRatio: aspectRatio, creditsUsed: creditsUsed })

      setProgress('video', 97, 'Download del video...')
      lastVideoUrl = url
      lastVideoPath = await api.downloadFile(url, 'frameai', 'mp4')

      if ($('gen-autoimport').checked) {
        setProgress('video', 99, 'Import nel progetto...')
        try { await importIntoAE(lastVideoPath, $('gen-makecomp').checked) }
        catch (e) { setError('gen-error', e.message) }
      }

      hideProgress('video')
      $('result-path-video').textContent = lastVideoPath
      $('result-wrap-video').classList.remove('hidden')
      refreshCredits()
    } catch (err) {
      hideProgress('video')
      setError('gen-error', (err && err.message) || 'Errore sconosciuto')
    } finally {
      btn.disabled = false
    }
  }

  // ════════════════════════════════════════════════════════
  // GENERA IMMAGINE
  // ════════════════════════════════════════════════════════
  async function generateImage() {
    const prompt = $('img-prompt').value.trim()
    if (!prompt) { setError('img-error', 'Scrivi un prompt prima di generare.'); return }
    setError('img-error', null)
    $('result-wrap-image').classList.add('hidden')

    const model = $('img-model').value
    const ratio = $('img-ratio').value
    const creditsUsed = api.getImageCreditCost(model)
    const btn = $('btn-generate-image')
    btn.disabled = true

    try {
      currentSession = await api.getSession()
      if (!currentSession) { showView('login'); return }
      const profile = await api.getProfile(currentSession)
      if (profile.credits < creditsUsed)
        throw new Error('Crediti insufficienti — hai ' + profile.credits + 'cr, servono ' + creditsUsed + 'cr.')

      setProgress('image', 20, 'Generazione immagine...')
      const url = await api.generateImage(currentSession, { prompt: prompt, model: model, ratio: ratio, resolution: '1024' })

      api.consumeCredits(currentSession, creditsUsed)
      api.saveGeneration(currentSession, url, { type: 'image', prompt: prompt, model: model, creditsUsed: creditsUsed })

      setProgress('image', 90, 'Download...')
      lastImageUrl = url
      lastImagePath = await api.downloadFile(url, 'frameai_img', 'jpg')

      if ($('img-autoimport').checked) {
        setProgress('image', 99, 'Import nel progetto...')
        try { await importIntoAE(lastImagePath, false) }
        catch (e) { setError('img-error', e.message) }
      }

      hideProgress('image')
      $('result-path-image').textContent = lastImagePath
      $('result-wrap-image').classList.remove('hidden')
      refreshCredits()
    } catch (err) {
      hideProgress('image')
      setError('img-error', (err && err.message) || 'Errore sconosciuto')
    } finally {
      btn.disabled = false
    }
  }

  // ════════════════════════════════════════════════════════
  // TOOLS
  // ════════════════════════════════════════════════════════
  async function runTool() {
    if (!toolFilePath) { setError('tools-error', 'Scegli un file da elaborare.'); return }

    const parts = $('tools-tool').value.split('|')
    const toolId = parts[0]
    const isVideo = parts[1] === 'video'
    const creditsUsed = parseInt(parts[2], 10)
    const needsPrompt = parts[3] === 'true'
    const prompt = needsPrompt ? $('tools-prompt').value.trim() : null

    if (needsPrompt && !prompt) { setError('tools-error', 'Scrivi cosa vuoi rimuovere.'); return }
    setError('tools-error', null)
    $('result-wrap-tools').classList.add('hidden')

    const btn = $('btn-run-tool')
    btn.disabled = true

    try {
      currentSession = await api.getSession()
      if (!currentSession) { showView('login'); return }
      const profile = await api.getProfile(currentSession)
      if (profile.credits < creditsUsed)
        throw new Error('Crediti insufficienti — hai ' + profile.credits + 'cr, servono ' + creditsUsed + 'cr.')

      setProgress('tools', 15, 'Upload del file...')
      const fileUrl = await api.uploadTemp(currentSession, toolFilePath)

      setProgress('tools', 35, 'Elaborazione AI...')
      const payload = { tool: toolId, fileUrl: fileUrl, userId: currentSession.userId, credits: creditsUsed }
      if (prompt) payload.bgPrompt = prompt

      const resp = await api.toolsProcess(currentSession, payload)
      let outUrl = resp.outputUrl

      if (!outUrl && resp.jobId) {
        let polls = 0
        while (polls < CFG.MAX_POLLS) {
          polls++
          await new Promise(function (r) { setTimeout(r, 5000) })
          const status = await api.toolJobStatus(currentSession, resp.jobId)
          if (!status) continue
          const prog = status.fal_progress || 0
          if (prog > 0)
            setProgress('tools', Math.min(92, 35 + prog * 0.55), 'Elaborazione... ' + Math.round(prog) + '%')
          else
            setProgress('tools', Math.min(92, 35 + (polls / 60) * 55), 'Elaborazione in corso...')
          if (status.status === 'done' && status.output_url) { outUrl = status.output_url; break }
          if (status.status === 'failed') throw new Error(status.error_msg || 'Elaborazione fallita')
        }
      }
      if (!outUrl) throw new Error('Timeout — nessun output dal tool.')

      api.consumeCredits(currentSession, creditsUsed)

      setProgress('tools', 95, 'Download del risultato...')
      const ext = isVideo ? 'mp4' : (toolId === 'remove-bg' ? 'png' : 'jpg')
      lastToolUrl = outUrl
      lastToolPath = await api.downloadFile(outUrl, 'frameai_' + toolId, ext)

      if ($('tools-autoimport').checked) {
        setProgress('tools', 99, 'Import nel progetto...')
        try { await importIntoAE(lastToolPath, false) }
        catch (e) { setError('tools-error', e.message) }
      }

      hideProgress('tools')
      $('result-path-tools').textContent = lastToolPath
      $('result-wrap-tools').classList.remove('hidden')
      refreshCredits()
    } catch (err) {
      hideProgress('tools')
      setError('tools-error', (err && err.message) || 'Errore sconosciuto')
    } finally {
      btn.disabled = false
    }
  }

  // ── Login / Logout ────────────────────────────────────────
  $('btn-login').addEventListener('click', async function () {
    setError('login-error', null)
    const email = $('login-email').value.trim()
    const password = $('login-password').value
    if (!email || !password) { setError('login-error', 'Inserisci email e password'); return }
    $('btn-login').disabled = true
    try {
      currentSession = await api.login(email, password)
      $('user-chip').classList.remove('hidden')
      showView('generator')
      updateVideoCost(); updateImageCost(); updateToolsUI()
      refreshCredits()
    } catch (err) {
      setError('login-error', err.message)
    } finally {
      $('btn-login').disabled = false
    }
  })

  $('btn-logout').addEventListener('click', function () {
    api.logout()
    currentSession = null
    $('user-chip').classList.add('hidden')
    showView('login')
  })

  // ── Pulsanti ─────────────────────────────────────────────
  $('btn-generate').addEventListener('click', generateVideo)
  $('btn-cancel-video').addEventListener('click', function () { cancelledVideo = true })

  $('btn-import-video').addEventListener('click', async function () {
    if (!lastVideoPath) return
    try { await importIntoAE(lastVideoPath, $('gen-makecomp').checked); setError('gen-error', null) }
    catch (e) { setError('gen-error', e.message) }
  })
  $('btn-open-url-video').addEventListener('click', function () {
    if (lastVideoUrl) window.cep.util.openURLInDefaultBrowser(lastVideoUrl)
  })

  $('btn-generate-image').addEventListener('click', generateImage)
  $('btn-import-image').addEventListener('click', async function () {
    if (!lastImagePath) return
    try { await importIntoAE(lastImagePath, false); setError('img-error', null) }
    catch (e) { setError('img-error', e.message) }
  })
  $('btn-open-url-image').addEventListener('click', function () {
    if (lastImageUrl) window.cep.util.openURLInDefaultBrowser(lastImageUrl)
  })

  $('btn-run-tool').addEventListener('click', runTool)
  $('btn-import-tools').addEventListener('click', async function () {
    if (!lastToolPath) return
    try { await importIntoAE(lastToolPath, false); setError('tools-error', null) }
    catch (e) { setError('tools-error', e.message) }
  })
  $('btn-open-url-tools').addEventListener('click', function () {
    if (lastToolUrl) window.cep.util.openURLInDefaultBrowser(lastToolUrl)
  })

  // ── Init ─────────────────────────────────────────────────
  ;(async function init() {
    if (CFG.SUPABASE_URL.indexOf('INSERISCI') !== -1 || CFG.SUPABASE_ANON_KEY.indexOf('INSERISCI') !== -1) {
      showView('config'); return
    }
    currentSession = await api.getSession()
    if (currentSession) {
      $('user-chip').classList.remove('hidden')
      showView('generator')
      updateVideoCost(); updateImageCost(); updateToolsUI()
      refreshCredits()
    } else {
      showView('login')
    }
  })()
})()
