// ============================================================
// FrameAI Plugin AE — Configurazione (globale, CEP)
// ⚠️ Stessi valori del plugin Premiere: copia da config.js
//    di premiere-uxp, o dal file .env di FrameAI
// ============================================================

window.FRAMEAI_CONFIG = {
  SUPABASE_URL: 'https://vyngrcrudvxoxbehwrqv.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0',

  POLL_INTERVAL_MS: 6000,
  MAX_POLLS: 200,
}
