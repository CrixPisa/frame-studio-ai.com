# FrameAI Studio — Plugin per Nuke (The Foundry)

Nuke non usa HTML/JS: i pannelli si scrivono in **Python + PySide**.
Questo plugin è un pannello dockabile che parla con le stesse edge
functions di FrameAI e crea un **Read node** col video generato.

---

## ⚙️ Installazione

### 1. Configura le chiavi
Apri `frameai_nuke.py` e compila in cima al file:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

(stessi valori pubblici degli altri plugin / del `.env` di FrameAI)

### 2. Copia i file nella cartella .nuke
La cartella si trova in:
- **Windows:** `C:\Users\<utente>\.nuke`
- **macOS/Linux:** `~/.nuke`

Copia lì `frameai_nuke.py`. Poi apri (o crea) il file `menu.py` nella
stessa cartella e aggiungi:

```python
import frameai_nuke
frameai_nuke.register()
```

### 3. Riavvia Nuke
Il pannello è registrato come widget custom: lo trovi cliccando con il
tasto destro sulla barra di un pane → **Windows → Custom → FrameAI Studio**
(puoi dockarlo accanto alle Properties, come ogni pannello nativo).

---

## 🎬 Come funziona

1. Login con le credenziali FrameAI (auth Supabase via REST)
2. Prompt + modello + formato + durata + risoluzione, con stima crediti
3. La generazione gira in un **QThread**: la UI di Nuke non si blocca mai
4. Polling su `poll-video` con progress bar reale
5. Crediti scalati con `consume-credits`, storico salvato con `save-generation`
6. Video scaricato in `~/FrameAI-Videos/`
7. **Read node** creato automaticamente nel node graph
   (via `nuke.executeInMainThread`, come richiede l'API di Nuke)

## 📝 Note tecniche

- Usa solo la **stdlib** Python (`urllib`) → niente pip, niente dipendenze
- Compatibile PySide2 (Nuke 12–15) con fallback PySide6 (Nuke 16+)
- I video MP4 si leggono nel Read node tramite il reader mov di Nuke;
  per pipeline VFX serie conviene convertire in sequenza EXR/DPX —
  possibile evoluzione: transcodifica automatica con ffmpeg
- Il file scaricato usa path con forward slash, come preferisce Nuke

## 🚀 Possibili evoluzioni

- [ ] Image-to-video: usa il frame corrente del Viewer come immagine di partenza
- [ ] Write node → upload del render su FrameAI per i tools (upscale, ecc.)
- [ ] Conversione automatica MP4 → sequenza EXR
- [ ] Distribuzione: zip con installer .py che copia i file in ~/.nuke
