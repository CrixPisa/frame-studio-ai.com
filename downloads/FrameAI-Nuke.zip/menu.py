# ============================================================
# FrameAI — menu.py per Nuke (Finestra Pop-up Corretta)
# ============================================================

import nuke
import frameai_nuke

# Crea una variabile globale per mantenere l'istanza della finestra in memoria
_frameai_window = None

def lancia_frameai_floating():
    global _frameai_window
    
    # Se la finestra esiste già ed è visibile, la portiamo in primo piano
    if _frameai_window is not None:
        _frameai_window.show()
        _frameai_window.raise_()
        _frameai_window.activateWindow()
        return

    # Inizializziamo il pannello PySide direttamente come finestra autonoma
    from frameai_nuke import FrameAIPanel
    _frameai_window = FrameAIPanel()
    
    # Impostiamo il flag per renderla una finestra indipendente (Pop-up fluttuante)
    from PySide2 import QtCore
    _frameai_window.setWindowFlags(QtCore.Qt.Window)
    _frameai_window.setWindowTitle("FrameAI Studio")
    
    _frameai_window.show()

# Creazione del pulsante nella barra laterale sinistra (Nodes)
toolbar = nuke.toolbar("Nodes")

# Percorso dell'icona (nella cartella .nuke) — Nuke vuole PNG, non SVG
# Usiamo le forward-slash e registriamo la cartella nel plugin path
import os
_nuke_dir = os.path.expanduser("~/.nuke").replace("\\", "/")
nuke.pluginAddPath(_nuke_dir)
_icon_file = _nuke_dir + "/frameai_icon.png"
_icon = _icon_file if os.path.isfile(_icon_file) else ""

# Crea l'icona nel menu laterale
frameai_menu = toolbar.addMenu("FrameAI", icon=_icon)

# Aggiunge il comando che apre la finestra pop-up autonoma al click
frameai_menu.addCommand(
    "FrameAI Studio",
    "lancia_frameai_floating()",
    icon=_icon
)
