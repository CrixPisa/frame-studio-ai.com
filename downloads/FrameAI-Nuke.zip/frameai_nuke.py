# ============================================================
# FrameAI Studio — Plugin per Nuke (The Foundry)
# Pannello PySide2: login -> genera -> polling -> Read node
# Solo stdlib (urllib) cosi' non servono pacchetti extra.
# ============================================================

import json
import os
import threading
import urllib.request
import urllib.error
from datetime import datetime

import nuke
import nukescripts

try:
    from PySide2 import QtWidgets, QtCore
except ImportError:  # Nuke 16+ usa PySide6
    from PySide6 import QtWidgets, QtCore

# ── CONFIGURAZIONE ──────────────────────────────────────────
# ⚠️ Stessi valori pubblici degli altri plugin (dal .env di FrameAI)
SUPABASE_URL = "https://vyngrcrudvxoxbehwrqv.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5bmdyY3J1ZHZ4b3hiZWh3cnF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2NTcxMzcsImV4cCI6MjA5MTIzMzEzN30.1chOitvn9dnuq7D1y3xWiTe_ShnB4CSm2QE-H-QLmf0"

POLL_INTERVAL_MS = 6000
MAX_POLLS = 200
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "FrameAI-Videos")

MODELS = [
    ("LTX-2 (Free)", "ltx-2"),
    ("Seedance 1.5 (Starter)", "seedance-1.5"),
    ("Seedance Fast (Starter)", "seedance-fast"),
    ("Wan 2.6 (Starter)", "wan-2.6"),
    ("Kling 3.0 (Creator)", "kling-3.0"),
    ("Seedance 2.0 (Creator)", "seedance-2.0"),
    ("Sora 2 (Business)", "sora-2"),
    ("Veo 3.1 (Agency)", "veo-3.1"),
]
RATIOS = ["16:9", "9:16", "1:1", "21:9", "4:3"]
DURATIONS = [5, 8, 10, 15]
RESOLUTIONS = ["720p", "1080p"]

# Modelli immagine (allineati a generate-image/index.ts)
IMAGE_MODELS = [
    ("Flux Schnell (Free)", "flux-schnell"),
    ("Flux Dev (Starter)", "flux-dev"),
    ("Flux 2 (Starter)", "flux2"),
    ("Nano Banana 2 (Creator)", "nano-banana-2"),
    ("Nano Banana Pro (Business)", "nano-banana-pro"),
    ("Seedream (Starter)", "seedream"),
]
IMAGE_RATIOS = ["1:1", "16:9", "9:16", "4:3"]

# Costo immagini (credit_cost_image)
_IMG_COST = {
    "flux-schnell": 1, "flux-dev": 1, "flux2": 2,
    "nano-banana-2": 2, "nano-banana-pro": 3, "seedream": 1,
}

# Tools utili dentro un compositor (single file in -> file out)
# (id, label, categoria input, crediti, serve_prompt)  input: 'image' | 'video'
TOOLS = [
    ("upscale-image",       "\U0001F50D Upscale Immagine",      "image", 1, False),
    ("enhance-photo",       "\u2728 Migliora Foto AI",           "image", 2, False),
    ("remove-bg",           "\u2702\uFE0F Rimuovi Sfondo",       "image", 1, False),
    ("remove-object",       "\U0001F9F9 Rimuovi Oggetto",        "image", 3, True),
    ("upscale-video",       "\U0001F3AC Upscale Video",          "video", 4, False),
    ("remove-bg-video",     "\u2702\uFE0F Rimuovi Sfondo Video", "video", 6, False),
    ("remove-object-video", "\U0001F9F9 Rimuovi Oggetto Video",  "video", 8, True),
]


def credit_cost_image(model):
    return _IMG_COST.get(model, 1)

# Replica di src/lib/credits.ts
_MAX_COST_PER_CREDIT = 0.063
_COST_PER_SEC = {
    "ltx-2": 0.004, "wan-2.6": 0.100, "seedance-2.0": 0.303,
    "seedance-fast": 0.242, "seedance-1.5": 0.052, "seedance-2-i2v": 0.242,
    "kling-3.0": 0.140, "sora-2": 0.150, "veo-3.1": 0.200,
}
_RES_MULT = {"720p": 1.0, "1080p": 1.5}


def credit_cost(model, duration, resolution="720p"):
    import math
    per_sec = _COST_PER_SEC.get(model, 0.10)
    usd = per_sec * duration * _RES_MULT.get(resolution, 1.0)
    return max(1, math.ceil(usd / _MAX_COST_PER_CREDIT))


# ── HTTP helper (stdlib) ────────────────────────────────────
def _request(url, payload=None, headers=None, method=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method or ("POST" if data else "GET"))
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=60) as res:
            return json.loads(res.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {}
        msg = body.get("error") or body.get("error_description") or body.get("msg") or str(e)
        raise RuntimeError(msg)


class FrameAIClient(object):
    """Client API — stessi contratti di useGeneration.ts"""

    def __init__(self):
        self.session = None

    # Auth
    def login(self, email, password):
        data = _request(
            SUPABASE_URL + "/auth/v1/token?grant_type=password",
            {"email": email, "password": password},
            {"apikey": SUPABASE_ANON_KEY},
        )
        self.session = {
            "access_token": data["access_token"],
            "refresh_token": data["refresh_token"],
            "user_id": data.get("user", {}).get("id"),
            "email": data.get("user", {}).get("email", email),
        }
        return self.session

    def _fn_headers(self, token):
        return {"Authorization": "Bearer " + token, "apikey": SUPABASE_ANON_KEY}

    def profile(self):
        rows = _request(
            SUPABASE_URL + "/rest/v1/profiles?id=eq.%s&select=credits,plan" % self.session["user_id"],
            headers=self._fn_headers(self.session["access_token"]),
        )
        if not rows:
            raise RuntimeError("Impossibile leggere il profilo")
        return rows[0]

    def generate_video(self, payload):
        data = _request(
            SUPABASE_URL + "/functions/v1/generate-video",
            payload,
            self._fn_headers(self.session["access_token"]),
        )
        if not data.get("id") or not data.get("modelId"):
            raise RuntimeError(data.get("error", "Risposta non valida dal server"))
        return data

    def poll_video(self, job_id, model_id):
        return _request(
            SUPABASE_URL + "/functions/v1/poll-video",
            {"requestId": job_id, "falEndpoint": model_id},
            self._fn_headers(SUPABASE_ANON_KEY),
        )

    def generate_image(self, payload):
        # generate-image risponde sincrono: {status:'success', output:[url]}
        data = _request(
            SUPABASE_URL + "/functions/v1/generate-image",
            payload,
            self._fn_headers(self.session["access_token"]),
        )
        if data.get("error"):
            raise RuntimeError(data["error"])
        out = data.get("output") or []
        url = out[0] if out else (data.get("imageUrl") or data.get("url"))
        if not url:
            raise RuntimeError("Nessuna immagine restituita")
        return url

    def upload_temp(self, file_path):
        # Upload multipart del file locale -> URL pubblico temporaneo
        import mimetypes, uuid
        boundary = "----FrameAINuke" + uuid.uuid4().hex
        with open(file_path, "rb") as fh:
            content = fh.read()
        fname = os.path.basename(file_path)
        ctype = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        body = b""
        body += ("--%s\r\n" % boundary).encode()
        body += ("Content-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n" % fname).encode()
        body += ("Content-Type: %s\r\n\r\n" % ctype).encode()
        body += content + b"\r\n"
        body += ("--%s--\r\n" % boundary).encode()
        req = urllib.request.Request(
            SUPABASE_URL + "/functions/v1/upload-temp",
            data=body, method="POST")
        req.add_header("Content-Type", "multipart/form-data; boundary=%s" % boundary)
        req.add_header("Authorization", "Bearer " + self.session["access_token"])
        req.add_header("apikey", SUPABASE_ANON_KEY)
        with urllib.request.urlopen(req, timeout=120) as res:
            data = json.loads(res.read().decode("utf-8"))
        if not data.get("url"):
            raise RuntimeError("Upload del file fallito")
        return data["url"]

    def tools_process(self, payload):
        return _request(
            SUPABASE_URL + "/functions/v1/tools-process",
            payload,
            self._fn_headers(self.session["access_token"]),
        )

    def tool_job_status(self, job_id):
        rows = _request(
            SUPABASE_URL + "/rest/v1/tool_jobs?id=eq.%s&select=status,output_url,error_msg,fal_progress" % job_id,
            headers=self._fn_headers(self.session["access_token"]),
        )
        return rows[0] if rows else None

    def consume_credits(self, amount):
        try:
            _request(
                SUPABASE_URL + "/functions/v1/consume-credits",
                {"userId": self.session["user_id"], "amount": amount},
                self._fn_headers(self.session["access_token"]),
            )
        except Exception:
            pass

    def save_generation(self, file_url, meta):
        try:
            payload = {"userId": self.session["user_id"], "fileUrl": file_url}
            payload.update(meta)
            _request(
                SUPABASE_URL + "/functions/v1/save-generation",
                payload,
                self._fn_headers(self.session["access_token"]),
            )
        except Exception:
            pass


# ── Worker thread (non blocca la UI di Nuke) ────────────────
class GenerateWorker(QtCore.QThread):
    progress = QtCore.Signal(int, str)
    finished_ok = QtCore.Signal(str)   # percorso file locale
    failed = QtCore.Signal(str)

    def __init__(self, client, payload, credits_used, parent=None):
        super(GenerateWorker, self).__init__(parent)
        self.client = client
        self.payload = payload
        self.credits_used = credits_used
        self.cancelled = False

    def run(self):
        try:
            self.progress.emit(15, "Avvio generazione...")
            job = self.client.generate_video(self.payload)

            self.progress.emit(30, "Rendering con %s..." % self.payload["model"])
            url = None
            polls = 0
            while polls < MAX_POLLS:
                if self.cancelled:
                    return
                polls += 1
                result = self.client.poll_video(job["id"], job["modelId"])
                url = result.get("outputUrl") or (result.get("output") or [None])[0]

                prog = result.get("progress") or 0
                if not result.get("done") and prog > 0:
                    self.progress.emit(int(min(95, 30 + prog * 0.65)),
                                       "Rendering... %d%%" % int(prog))
                else:
                    self.progress.emit(int(min(95, 30 + (polls / 100.0) * 65)),
                                       "Rendering in corso...")

                done = result.get("done") or result.get("status") in ("success", "COMPLETED")
                if done and url:
                    break
                if result.get("status") == "error":
                    raise RuntimeError(result.get("error", "Rendering fallito"))

                self.msleep(POLL_INTERVAL_MS)

            if not url:
                raise RuntimeError("Timeout — riprova con durata minore.")

            self.client.consume_credits(self.credits_used)
            self.client.save_generation(url, {
                "type": "video",
                "prompt": self.payload["prompt"],
                "model": self.payload["model"],
                "aspectRatio": self.payload["aspectRatio"],
                "creditsUsed": self.credits_used,
            })

            self.progress.emit(97, "Download del video...")
            if not os.path.isdir(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR)
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            file_path = os.path.join(DOWNLOAD_DIR, "frameai_%s.mp4" % stamp)
            urllib.request.urlretrieve(url, file_path)

            self.finished_ok.emit(file_path)
        except Exception as e:
            self.failed.emit(str(e))


# ── Worker IMMAGINE ─────────────────────────────────────────
class ImageWorker(QtCore.QThread):
    progress = QtCore.Signal(int, str)
    finished_ok = QtCore.Signal(str)
    failed = QtCore.Signal(str)

    def __init__(self, client, payload, credits_used, parent=None):
        super(ImageWorker, self).__init__(parent)
        self.client = client
        self.payload = payload
        self.credits_used = credits_used

    def run(self):
        try:
            self.progress.emit(25, "Generazione immagine...")
            url = self.client.generate_image(self.payload)
            self.client.consume_credits(self.credits_used)
            self.client.save_generation(url, {
                "type": "image",
                "prompt": self.payload.get("prompt", ""),
                "model": self.payload.get("model", ""),
                "creditsUsed": self.credits_used,
            })
            self.progress.emit(90, "Download...")
            if not os.path.isdir(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR)
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            file_path = os.path.join(DOWNLOAD_DIR, "frameai_img_%s.jpg" % stamp)
            urllib.request.urlretrieve(url, file_path)
            self.finished_ok.emit(file_path)
        except Exception as e:
            self.failed.emit(str(e))


# ── Worker TOOLS ────────────────────────────────────────────
class ToolWorker(QtCore.QThread):
    progress = QtCore.Signal(int, str)
    finished_ok = QtCore.Signal(str)
    failed = QtCore.Signal(str)

    def __init__(self, client, tool_id, input_path, is_video, credits_used, prompt=None, parent=None):
        super(ToolWorker, self).__init__(parent)
        self.client = client
        self.tool_id = tool_id
        self.input_path = input_path
        self.is_video = is_video
        self.credits_used = credits_used
        self.prompt = prompt

    def run(self):
        try:
            self.progress.emit(15, "Upload del file...")
            file_url = self.client.upload_temp(self.input_path)

            self.progress.emit(35, "Elaborazione AI...")
            payload = {
                "tool": self.tool_id,
                "fileUrl": file_url,
                "userId": self.client.session["user_id"],
                "credits": self.credits_used,
            }
            # I tool di object-removal usano 'bgPrompt' per dire cosa togliere
            if self.prompt:
                payload["bgPrompt"] = self.prompt
            resp = self.client.tools_process(payload)
            if resp.get("error"):
                raise RuntimeError(resp["error"])

            out_url = resp.get("outputUrl")
            # Se sincrono, abbiamo gia' l'output. Altrimenti polling sul job.
            if not out_url and resp.get("jobId"):
                job_id = resp["jobId"]
                polls = 0
                while polls < MAX_POLLS:
                    polls += 1
                    self.msleep(5000)
                    status = self.client.tool_job_status(job_id)
                    if not status:
                        continue
                    prog = status.get("fal_progress") or 0
                    if prog > 0:
                        self.progress.emit(int(min(92, 35 + prog * 0.55)),
                                           "Elaborazione... %d%%" % int(prog))
                    else:
                        self.progress.emit(int(min(92, 35 + (polls / 60.0) * 55)),
                                           "Elaborazione in corso...")
                    if status.get("status") == "done" and status.get("output_url"):
                        out_url = status["output_url"]
                        break
                    if status.get("status") == "failed":
                        raise RuntimeError(status.get("error_msg") or "Elaborazione fallita")

            if not out_url:
                raise RuntimeError("Timeout — nessun output dal tool.")

            self.client.consume_credits(self.credits_used)
            self.progress.emit(95, "Download del risultato...")
            if not os.path.isdir(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR)
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            ext = "mp4" if self.is_video else ("png" if self.tool_id == "remove-bg" else "jpg")
            file_path = os.path.join(DOWNLOAD_DIR, "frameai_%s_%s.%s" % (self.tool_id, stamp, ext))
            urllib.request.urlretrieve(out_url, file_path)
            self.finished_ok.emit(file_path)
        except Exception as e:
            self.failed.emit(str(e))


# ── Pannello ────────────────────────────────────────────────
class FrameAIPanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(FrameAIPanel, self).__init__(parent)
        self.client = FrameAIClient()
        self.worker = None
        self._build_ui()
        self._show_login(SUPABASE_URL.find("INSERISCI") == -1)

    # UI
    def _build_ui(self):
        self.setStyleSheet("""
            QWidget { background: #0d0f14; color: #e7e9ee; font-size: 12px; }
            QLineEdit, QTextEdit, QComboBox {
                background: #1a1e29; border: 1px solid #2a3042;
                border-radius: 6px; padding: 6px; }
            QPushButton { background: #a855f7; color: white; border: none;
                border-radius: 6px; padding: 8px 12px; font-weight: bold; }
            QPushButton:disabled { background: #4a3a5e; }
            QPushButton#secondary { background: #232838; }
            QPushButton#mode { background: #1a1e29; color: #8b90a0; padding: 7px;
                border: 1px solid #2a3042; font-weight: bold; }
            QPushButton#mode:checked { background: #a855f7; color: white; border: none; }
            QProgressBar { background: #1a1e29; border: none; border-radius: 4px;
                height: 8px; text-align: center; }
            QProgressBar::chunk { background: #a855f7; border-radius: 4px; }
            QLabel#muted { color: #8b90a0; }
            QLabel#error { color: #f43f5e; }
            QLabel#credits { color: #f59e0b; font-weight: bold; }
        """)
        root = QtWidgets.QVBoxLayout(self)

        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("<b>FrameAI</b> Studio · Nuke")
        self.credits_lbl = QtWidgets.QLabel("")
        self.credits_lbl.setObjectName("credits")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.credits_lbl)
        root.addLayout(header)

        # Login box
        self.login_box = QtWidgets.QWidget()
        lb = QtWidgets.QVBoxLayout(self.login_box)
        self.email_edit = QtWidgets.QLineEdit()
        self.email_edit.setPlaceholderText("Email FrameAI")
        self.pass_edit = QtWidgets.QLineEdit()
        self.pass_edit.setPlaceholderText("Password")
        self.pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.login_btn = QtWidgets.QPushButton("Accedi")
        self.login_btn.clicked.connect(self.do_login)
        lb.addWidget(self.email_edit)
        lb.addWidget(self.pass_edit)
        lb.addWidget(self.login_btn)
        root.addWidget(self.login_box)

        # Generator box (con tab Video / Immagine / Tools)
        self.gen_box = QtWidgets.QWidget()
        gb = QtWidgets.QVBoxLayout(self.gen_box)
        gb.setContentsMargins(0, 0, 0, 0)

        # Selettore modalita'
        mode_row = QtWidgets.QHBoxLayout()
        self.mode_video_btn = QtWidgets.QPushButton("\U0001F3AC Video")
        self.mode_image_btn = QtWidgets.QPushButton("\U0001F5BC Immagine")
        self.mode_tools_btn = QtWidgets.QPushButton("\U0001F527 Tools")
        for b in (self.mode_video_btn, self.mode_image_btn, self.mode_tools_btn):
            b.setObjectName("mode")
            b.setCheckable(True)
            mode_row.addWidget(b)
        self.mode_video_btn.setChecked(True)
        self.mode_video_btn.clicked.connect(lambda: self._set_mode("video"))
        self.mode_image_btn.clicked.connect(lambda: self._set_mode("image"))
        self.mode_tools_btn.clicked.connect(lambda: self._set_mode("tools"))
        gb.addLayout(mode_row)

        self.stack = QtWidgets.QStackedWidget()
        gb.addWidget(self.stack)

        # ===== PAGINA VIDEO =====
        video_page = QtWidgets.QWidget()
        vp = QtWidgets.QVBoxLayout(video_page)
        vp.setContentsMargins(0, 8, 0, 0)

        self.prompt_edit = QtWidgets.QTextEdit()
        self.prompt_edit.setPlaceholderText("Descrivi la scena... (in italiano, lo ottimizza il backend)")
        self.prompt_edit.setFixedHeight(70)
        vp.addWidget(self.prompt_edit)

        row1 = QtWidgets.QHBoxLayout()
        self.model_combo = QtWidgets.QComboBox()
        for label, value in MODELS:
            self.model_combo.addItem(label, value)
        self.model_combo.setCurrentIndex(3)  # wan-2.6
        self.ratio_combo = QtWidgets.QComboBox()
        self.ratio_combo.addItems(RATIOS)
        row1.addWidget(self.model_combo, 2)
        row1.addWidget(self.ratio_combo, 1)
        vp.addLayout(row1)

        row2 = QtWidgets.QHBoxLayout()
        self.duration_combo = QtWidgets.QComboBox()
        for d in DURATIONS:
            self.duration_combo.addItem("%ds" % d, d)
        self.res_combo = QtWidgets.QComboBox()
        self.res_combo.addItems(RESOLUTIONS)
        self.cost_lbl = QtWidgets.QLabel("")
        self.cost_lbl.setObjectName("credits")
        row2.addWidget(self.duration_combo)
        row2.addWidget(self.res_combo)
        row2.addStretch()
        row2.addWidget(self.cost_lbl)
        vp.addLayout(row2)

        self.autoread_check = QtWidgets.QCheckBox("Crea Read node automaticamente")
        self.autoread_check.setChecked(True)
        vp.addWidget(self.autoread_check)

        self.generate_btn = QtWidgets.QPushButton("\U0001F3AC Genera video")
        self.generate_btn.clicked.connect(self.do_generate)
        vp.addWidget(self.generate_btn)
        vp.addStretch()
        self.stack.addWidget(video_page)

        # ===== PAGINA IMMAGINE =====
        image_page = QtWidgets.QWidget()
        ip = QtWidgets.QVBoxLayout(image_page)
        ip.setContentsMargins(0, 8, 0, 0)

        self.img_prompt_edit = QtWidgets.QTextEdit()
        self.img_prompt_edit.setPlaceholderText("Descrivi l'immagine... (in italiano)")
        self.img_prompt_edit.setFixedHeight(70)
        ip.addWidget(self.img_prompt_edit)

        irow = QtWidgets.QHBoxLayout()
        self.img_model_combo = QtWidgets.QComboBox()
        for label, value in IMAGE_MODELS:
            self.img_model_combo.addItem(label, value)
        self.img_model_combo.setCurrentIndex(1)  # flux-dev
        self.img_ratio_combo = QtWidgets.QComboBox()
        self.img_ratio_combo.addItems(IMAGE_RATIOS)
        irow.addWidget(self.img_model_combo, 2)
        irow.addWidget(self.img_ratio_combo, 1)
        ip.addLayout(irow)

        irow2 = QtWidgets.QHBoxLayout()
        self.img_autoread_check = QtWidgets.QCheckBox("Crea Read node automaticamente")
        self.img_autoread_check.setChecked(True)
        self.img_cost_lbl = QtWidgets.QLabel("")
        self.img_cost_lbl.setObjectName("credits")
        irow2.addWidget(self.img_autoread_check)
        irow2.addStretch()
        irow2.addWidget(self.img_cost_lbl)
        ip.addLayout(irow2)

        self.img_generate_btn = QtWidgets.QPushButton("\U0001F5BC Genera immagine")
        self.img_generate_btn.clicked.connect(self.do_generate_image)
        ip.addWidget(self.img_generate_btn)
        ip.addStretch()
        self.stack.addWidget(image_page)

        # ===== PAGINA TOOLS =====
        tools_page = QtWidgets.QWidget()
        tp = QtWidgets.QVBoxLayout(tools_page)
        tp.setContentsMargins(0, 8, 0, 0)

        self.tool_combo = QtWidgets.QComboBox()
        for tid, label, cat, cr, needs_prompt in TOOLS:
            self.tool_combo.addItem("%s  (%dcr)" % (label, cr), tid)
        tp.addWidget(self.tool_combo)

        self.tool_hint = QtWidgets.QLabel("")
        self.tool_hint.setObjectName("muted")
        self.tool_hint.setWordWrap(True)
        tp.addWidget(self.tool_hint)

        # Campo prompt (mostrato solo per i tool che lo richiedono, es. rimuovi oggetto)
        self.tool_prompt_edit = QtWidgets.QLineEdit()
        self.tool_prompt_edit.setPlaceholderText("Cosa rimuovere (in inglese): the car, the person...")
        self.tool_prompt_edit.hide()
        tp.addWidget(self.tool_prompt_edit)

        self.tool_file_btn = QtWidgets.QPushButton("\U0001F4C1 Scegli file...")
        self.tool_file_btn.setObjectName("secondary")
        self.tool_file_btn.clicked.connect(self._pick_tool_file)
        tp.addWidget(self.tool_file_btn)

        self.tool_file_lbl = QtWidgets.QLabel("")
        self.tool_file_lbl.setObjectName("muted")
        self.tool_file_lbl.setWordWrap(True)
        tp.addWidget(self.tool_file_lbl)

        self.tool_autoread_check = QtWidgets.QCheckBox("Crea Read node automaticamente")
        self.tool_autoread_check.setChecked(True)
        tp.addWidget(self.tool_autoread_check)

        self.tool_run_btn = QtWidgets.QPushButton("\U0001F527 Elabora")
        self.tool_run_btn.clicked.connect(self.do_run_tool)
        tp.addWidget(self.tool_run_btn)
        tp.addStretch()
        self.stack.addWidget(tools_page)

        self._tool_file_path = None
        self.tool_combo.currentIndexChanged.connect(self._update_tool_hint)

        # Progress condiviso
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.hide()
        self.progress_lbl = QtWidgets.QLabel("")
        self.progress_lbl.setObjectName("muted")
        gb.addWidget(self.progress_bar)
        gb.addWidget(self.progress_lbl)

        root.addWidget(self.gen_box)

        self.error_lbl = QtWidgets.QLabel("")
        self.error_lbl.setObjectName("error")
        self.error_lbl.setWordWrap(True)
        root.addWidget(self.error_lbl)
        root.addStretch()

        for combo in (self.model_combo, self.duration_combo, self.res_combo):
            combo.currentIndexChanged.connect(self.update_cost)
        self.img_model_combo.currentIndexChanged.connect(self.update_img_cost)
        self.update_cost()
        self.update_img_cost()
        self._update_tool_hint()

    def _set_mode(self, mode):
        idx = {"video": 0, "image": 1, "tools": 2}[mode]
        self.stack.setCurrentIndex(idx)
        self.mode_video_btn.setChecked(mode == "video")
        self.mode_image_btn.setChecked(mode == "image")
        self.mode_tools_btn.setChecked(mode == "tools")
        self.error_lbl.setText("")

    def _pick_tool_file(self):
        tid = self.tool_combo.currentData()
        cat = next((c for t, l, c, cr, p in TOOLS if t == tid), "image")
        if cat == "video":
            flt = "Video (*.mp4 *.mov *.webm *.avi)"
        else:
            flt = "Immagini (*.png *.jpg *.jpeg *.webp *.exr *.tif *.tiff)"
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Scegli file", "", flt)
        if path:
            self._tool_file_path = path
            self.tool_file_lbl.setText("\u2713 " + os.path.basename(path))

    def _update_tool_hint(self):
        tid = self.tool_combo.currentData()
        cat = next((c for t, l, c, cr, p in TOOLS if t == tid), "image")
        needs_prompt = next((p for t, l, c, cr, p in TOOLS if t == tid), False)
        self.tool_hint.setText(
            "Input: %s \u00b7 il risultato viene scaricato e importato come Read node."
            % ("video" if cat == "video" else "immagine"))
        self.tool_prompt_edit.setVisible(bool(needs_prompt))
        self.tool_prompt_edit.clear()
        self._tool_file_path = None
        self.tool_file_lbl.setText("")

    def _show_login(self, configured):
        if not configured:
            self.login_box.hide()
            self.gen_box.hide()
            self.error_lbl.setText(
                "Configurazione mancante: apri frameai_nuke.py e compila "
                "SUPABASE_URL e SUPABASE_ANON_KEY.")
            return
        self.gen_box.hide()
        self.login_box.show()

    def update_cost(self):
        cost = credit_cost(
            self.model_combo.currentData(),
            self.duration_combo.currentData(),
            self.res_combo.currentText(),
        )
        self.cost_lbl.setText("⚡ %dcr" % cost)

    def update_img_cost(self):
        cost = credit_cost_image(self.img_model_combo.currentData())
        self.img_cost_lbl.setText("⚡ %dcr" % cost)

    def _make_read_node(self, file_path, label="FrameAI"):
        path_fwd = file_path.replace("\\", "/")
        def make_read():
            read = nuke.createNode("Read", inpanel=False)
            read["file"].fromUserText(path_fwd)
            read["label"].setValue(label)
            # Imposta il frame range reale del file (per i video, altrimenti resta 1-1)
            try:
                first = int(read["first"].value())
                last = int(read["last"].value())
                if last > first:
                    # Adatta il frame range del progetto e del Viewer al clip
                    nuke.root()["first_frame"].setValue(first)
                    nuke.root()["last_frame"].setValue(last)
                    # Riporta il playhead all'inizio del clip
                    try:
                        v = nuke.activeViewer()
                        if v:
                            v.node()["frame_range_lock"].setValue(False)
                            v.frameControl(0)  # vai al primo frame
                    except Exception:
                        pass
            except Exception:
                pass
            # Collega automaticamente il Read al Viewer attivo
            try:
                nuke.connectViewer(0, read)
            except Exception:
                pass
        nuke.executeInMainThread(make_read)

    def _refresh_credits(self):
        try:
            profile = self.client.profile()
            self.credits_lbl.setText("⚡ %scr · %s" % (profile["credits"], profile["plan"]))
        except Exception:
            pass

    def _set_busy(self, busy):
        for b in (self.generate_btn, self.img_generate_btn, self.tool_run_btn):
            b.setEnabled(not busy)
        if busy:
            self.error_lbl.setText("")
            self.progress_bar.show()
            self.progress_bar.setValue(5)

    # Azioni
    def do_login(self):
        self.error_lbl.setText("")
        try:
            self.client.login(self.email_edit.text().strip(), self.pass_edit.text())
            profile = self.client.profile()
            self.credits_lbl.setText("⚡ %scr · %s" % (profile["credits"], profile["plan"]))
            self.login_box.hide()
            self.gen_box.show()
        except Exception as e:
            self.error_lbl.setText(str(e))

    def do_generate(self):
        prompt = self.prompt_edit.toPlainText().strip()
        if not prompt:
            self.error_lbl.setText("Scrivi un prompt prima di generare.")
            return
        self.error_lbl.setText("")

        model = self.model_combo.currentData()
        duration = self.duration_combo.currentData()
        resolution = self.res_combo.currentText()
        credits_used = credit_cost(model, duration, resolution)

        try:
            profile = self.client.profile()
            if profile["credits"] < credits_used:
                self.error_lbl.setText(
                    "Crediti insufficienti — hai %scr, servono %dcr." % (profile["credits"], credits_used))
                return
        except Exception as e:
            self.error_lbl.setText(str(e))
            return

        payload = {
            "prompt": prompt,
            "model": model,
            "aspectRatio": self.ratio_combo.currentText(),
            "duration": duration,
            "resolution": resolution,
        }

        self.generate_btn.setEnabled(False)
        self.progress_bar.show()
        self.progress_bar.setValue(5)

        self.worker = GenerateWorker(self.client, payload, credits_used, self)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def do_generate_image(self):
        prompt = self.img_prompt_edit.toPlainText().strip()
        if not prompt:
            self.error_lbl.setText("Scrivi un prompt prima di generare.")
            return
        model = self.img_model_combo.currentData()
        credits_used = credit_cost_image(model)
        try:
            profile = self.client.profile()
            if profile["credits"] < credits_used:
                self.error_lbl.setText(
                    "Crediti insufficienti — hai %scr, servono %dcr." % (profile["credits"], credits_used))
                return
        except Exception as e:
            self.error_lbl.setText(str(e))
            return
        payload = {
            "prompt": prompt,
            "model": model,
            "ratio": self.img_ratio_combo.currentText(),
            "resolution": "1024",
        }
        self._set_busy(True)
        self.worker = ImageWorker(self.client, payload, credits_used, self)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(self.on_done_image)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def do_run_tool(self):
        if not self._tool_file_path:
            self.error_lbl.setText("Scegli un file da elaborare.")
            return
        tid = self.tool_combo.currentData()
        cat = next((c for t, l, c, cr, p in TOOLS if t == tid), "image")
        credits_used = next((cr for t, l, c, cr, p in TOOLS if t == tid), 1)
        needs_prompt = next((p for t, l, c, cr, p in TOOLS if t == tid), False)
        is_video = (cat == "video")
        prompt = self.tool_prompt_edit.text().strip() if needs_prompt else None
        if needs_prompt and not prompt:
            self.error_lbl.setText("Scrivi cosa rimuovere.")
            return
        try:
            profile = self.client.profile()
            if profile["credits"] < credits_used:
                self.error_lbl.setText(
                    "Crediti insufficienti — hai %scr, servono %dcr." % (profile["credits"], credits_used))
                return
        except Exception as e:
            self.error_lbl.setText(str(e))
            return
        self._set_busy(True)
        self.worker = ToolWorker(self.client, tid, self._tool_file_path, is_video, credits_used, prompt, self)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(self.on_done_tool)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def on_progress(self, pct, label):
        self.progress_bar.setValue(pct)
        self.progress_lbl.setText(label)

    def on_done_image(self, file_path):
        self.progress_bar.setValue(100)
        self.progress_lbl.setText("✅ Immagine pronta: " + file_path)
        self._set_busy(False)
        self._refresh_credits()
        if self.img_autoread_check.isChecked():
            self._make_read_node(file_path, "FrameAI img")

    def on_done_tool(self, file_path):
        self.progress_bar.setValue(100)
        self.progress_lbl.setText("✅ Risultato pronto: " + file_path)
        self._set_busy(False)
        self._refresh_credits()
        if self.tool_autoread_check.isChecked():
            self._make_read_node(file_path, "FrameAI tool")

    def on_done(self, file_path):
        self.progress_bar.setValue(100)
        self.progress_lbl.setText("✅ Video pronto: " + file_path)
        self._set_busy(False)
        self._refresh_credits()
        if self.autoread_check.isChecked():
            self._make_read_node(file_path, "FrameAI video")

    def on_failed(self, msg):
        self.progress_bar.hide()
        self.progress_lbl.setText("")
        self.error_lbl.setText(msg)
        for b in (self.generate_btn, self.img_generate_btn, self.tool_run_btn):
            b.setEnabled(True)


# ── Registrazione pannello in Nuke ──────────────────────────
def register():
    # Registra il widget come pannello agganciabile, impostandolo in background
    nukescripts.panels.registerWidgetAsPanel(
        "frameai_nuke.FrameAIPanel",
        "FrameAI Studio",
        "ai.frameai.nuke.panel",
        False  # Impostato su False impedisce a Nuke di aprirlo automaticamente all'avvio
    )
